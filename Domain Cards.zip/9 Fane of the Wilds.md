---
Color: "#197d4a"
Domain: Sage
Level: "9"
tags:
  - level9
---

##### -- Fane of the Wilds
Level: 9
Domain: Sage
Type: Ability
Recall Cost: 2
After a long rest, place a number of tokens equal to the number of Sage domain cards in your loadout and vault on this card.

When you would make a Spellcast Roll, you can spend any number of tokens after the roll to gain a +1 bonus for each token spent.

When you critically succeed on a Spellcast Roll for a Sage domain spell, gain a token.