---
Color: "#6c1713"
Domain: Blood
Level: "2"
tags:
  - level2
---

##### -- Brand of Castigation
Level: 2
Domain: Blade
Type: Spell
Recall Cost: 1
When you deal damage to a creature, mark a Stress to sear a red, magical mark on them. Until this mark disappears, you always know the direction of the marked creature relative to you, and that creature marks a Stress each time it deals damage to you or an ally of yours within Very Close range of you. The mark disappears when you use this spell again.