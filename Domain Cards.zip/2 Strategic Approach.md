---
Color: "#999b9c"
Domain: Bone
Level: "2"
tags:
  - level2
---

##### -- Strategic Approach
Level: 2
Domain: Bone
Type: Ability
Recall Cost: 1
After a long rest, place a number of tokens equal to your Knowledge on this card (minimum 1). The first time you move within Close range of an adversary and make an attack against them, you can spend one token to choose one of the following options:

- You make the attack with advantage.
- You clear a Stress on an ally within Melee range of the adversary.
- You add a d 8 to your damage roll.

When you take a long rest, clear all unspent tokens.