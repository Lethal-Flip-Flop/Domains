---
Color: "#6c1713"
Domain: Blood
Level: "9"
tags:
  - level9
---

##### -- Glyph of Hemorrhaging
Level: 9
Domain: Blood
Type: Spell
Recall Cost: 1
Make a Spellcast Roll against a creature within Far range. On a success, mark a Hit Point to sear the target with a magical glyph that lasts until the GM spends 2 Fear to remove it or you take Severe damage. Whenever the target marks any Hit Points while the glyph remains, you can mark a Stress to make them mark an additional Hit Point.