---
Color: "#197d4a"
Domain: Sage
Level: "3"
tags:
  - level3
---

##### -- Corrosive Projectile
Level: 3
Domain: Sage
Type: Spell
Recall Cost: 1
Make a Spellcast Roll against a target within Far range. On a success, deal d6+4 magic damage using your Proficiency. Additionally, mark 2 or more Stress to make them permanently Corroded. While a target is Corroded, they gain a −1 penalty to their Difficulty for every 2 Stress you spent. This condition can stack.