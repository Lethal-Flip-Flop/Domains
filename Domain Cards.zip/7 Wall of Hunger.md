---
Color: "#3a3174"
Domain: Dread
Level: "7"
tags:
  - level7
---

##### -- Wall of Hunger
Level: 7
Domain: Dread
Type: Spell
Recall Cost: 2
Succeed on a Spellcast Roll (13) to create a visible wall of writhing, necrotic energy in a line between two points within Far range that lasts until you mark a Hit Point or cast this spell again. Any creatures inside the wall when it appears or who try to pass through the wall must mark 2 Stress, then make a Reaction Roll (16) . On a failure, they are temporarily Restrained by the wall.