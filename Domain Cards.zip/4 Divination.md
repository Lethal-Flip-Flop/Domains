---
Color: "#dabb2e"
Domain: Splendor
Level: "4"
tags:
  - level4
---

##### -- Divination
Level: 4
Domain: Splendor
Type: Spell
Recall Cost: 1
Once per long rest, spend 3 Hope to reach out to the forces beyond and ask one “yes or no” question about an event, person, place, or situation in the near future. For a moment, the present falls away and you see the answer before you.