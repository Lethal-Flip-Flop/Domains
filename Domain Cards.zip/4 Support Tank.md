---
Color: "#cd762a"
Domain: Valor
Level: "4"
tags:
  - level4
---

##### -- Support Tank
Level: 4
Domain: Valor
Type: Ability
Recall Cost: 2
When an ally within Close range fails a roll, you can spend 2 Hope to allow them to reroll either their Hope or Fear Die.