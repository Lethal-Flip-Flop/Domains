---
Color: "#3a3174"
Domain: Dread
Level: "1"
tags:
  - Level1
---

##### -- Blighting Strike
Level: 1 
Domain: Dread
Type: Spell
Recall Cost: 1
Make a Spellcast Roll against a target within Far range. On a success, the target takes d6+1 magic damage using your Proficiency and the next time the target deals damage to an ally, it is reduced by half. If you succeed with Fear, the target instead takes d10+1 magic damage using your Proficiency.
