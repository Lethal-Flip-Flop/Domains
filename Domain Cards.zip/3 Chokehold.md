---
Color: "#434445"
Domain: Midnight
Level: "3"
tags:
  - level3
---

##### -- Chokehold
Level: 3
Domain: Midnight
Type: Ability
Recall Cost: 1
When you position yourself behind a creature who’s about your size, you can mark a Stress to pull them into a chokehold, making them temporarily Vulnerable.

When a creature attacks a target who is Vulnerable in this way, they deal an extra 2 d 6 damage.