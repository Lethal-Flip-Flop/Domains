---
Color: "#385e8e"
Domain: Codex
Level: "8"
tags:
  - level8
---

##### -- Book of Vyola
Level: 8
Domain: Codex
Type: Grimoire
Recall Cost: 2
Memory Delve: Make a Spellcast Roll against a target within Far range. On a success, peer into the target’s mind and ask the GM a question. The GM describes any memories the target has pertaining to the answer.

Shared Clarity: Once per long rest, spend a Hope to choose two willing creatures. When one of them would mark Stress, they can choose between the two of them who marks it. This spell lasts until their next rest.