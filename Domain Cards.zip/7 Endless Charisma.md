---
Color: "#b03a7c"
Domain: Grace
Level: "7"
tags:
  - level7
---

##### -- Endless Charisma
Level: 7
Domain: Grace
Type: Ability
Recall Cost: 1
After you make an action roll to persuade, lie, or garner favor, you can spend a Hope to reroll the Hope or Fear Die.