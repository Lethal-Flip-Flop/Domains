---
Color: "#9f3630"
Domain: Blade
Level: "2"
tags:
  - level2
---

##### -- Reckless
Level: 2
Domain: Blade
Type: Ability
Recall Cost: 1
Mark a Stress to gain advantage on an attack.