---
Color: "#9f3630"
Domain: Blade
Level: "9"
tags:
  - level9
---

##### -- Gore and Glory
Level: 9
Domain: Blade
Type: Ability
Recall Cost: 2
When you critically succeed on a weapon attack, gain an additional Hope or clear an additional Stress.

Additionally, when you deal enough damage to defeat an enemy, gain a Hope or clear a Stress.