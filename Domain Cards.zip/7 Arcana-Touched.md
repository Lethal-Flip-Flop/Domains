---
Color: "#895b95"
Domain: Arcana
Level: "7"
tags:
  - level7
---

##### -- Arcana-Touched
Level: 7
Domain: Arcana
Type: Ability
Recall Cost: 2
When 4 or more of the domain cards in your loadout are from the Arcana domain, gain the following benefits:

- +1 bonus to your Spellcast Rolls
- Once per rest, you can switch the results of your Hope and Fear Dice.