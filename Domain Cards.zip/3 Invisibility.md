---
Color: "#b03a7c"
Domain: Grace
Level: "3"
tags:
  - level3
---

##### -- Invisibility
Level: 3
Domain: Grace
Type: Spell
Recall Cost: 1
Make a Spellcast Roll (10). On a success, mark a Stress and choose yourself or an ally within Melee range to become Invisible. An Invisible creature can’t be seen except through magical means and attack rolls against them are made with disadvantage. Place a number of tokens on this card equal to your Spellcast trait. When the Invisible creature takes an action, spend a token from this card. After the action that spends the last token is resolved, the effect ends.

You can only hold Invisibility on one creature at a time.