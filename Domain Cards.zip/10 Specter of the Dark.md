---
Color: "#434445"
Domain: Midnight
Level: "10"
tags:
  - level10
---

##### -- Specter of the Dark
Level: 10
Domain: Midnight
Type: Spell
Recall Cost: 1
Mark a Stress to become Spectral until you make an action roll targeting another creature. While Spectral, you’re immune to physical damage and can float and pass through solid objects. Other creatures can still see you while you’re in this form.