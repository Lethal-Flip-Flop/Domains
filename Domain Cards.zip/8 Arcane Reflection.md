---
Color: "#895b95"
Domain: Arcana
Level: "8"
tags:
  - level8
---

##### -- Arcane Reflection
Level: 8
Domain: Arcana
Type: Spell
Recall Cost: 1
When you would take magic damage, you can spend any number of Hope to roll that many d6s. If any roll a 6, the attack is reflected back to the caster, dealing the damage to them instead.