---
Color: "#9f3630"
Domain: Blade
Level: "7"
tags:
  - level7
---

##### -- Blade-Touched
Level: 7
Domain: Blade
Type: Ability
Recall Cost: 1
When 4 or more of the domain cards in your loadout are from the Blade domain, gain the following benefits:

- +2 bonus to your attack rolls
- +4 bonus to your Severe damage threshold