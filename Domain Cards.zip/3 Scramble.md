---
Color: "#9f3630"
Domain: Blade
Level: "3"
tags:
  - level3
---

##### -- Scramble
Level: 3
Domain: Blade
Type: Ability
Recall Cost: 1
Once per rest, when a creature within Melee range would deal damage to you, you can avoid the attack and safely move out of Melee range of the enemy.