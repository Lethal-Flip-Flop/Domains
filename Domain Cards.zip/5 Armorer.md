---
Color: "#cd762a"
Domain: Valor
Level: "5"
tags:
  - level5
---

##### -- Armorer
Level: 5
Domain: Valor
Type: Ability
Recall Cost: 1
While you’re wearing armor, gain a +1 bonus to your Armor Score.

During a rest, when you choose to repair your armor as a downtime move, your allies also clear an Armor Slot.