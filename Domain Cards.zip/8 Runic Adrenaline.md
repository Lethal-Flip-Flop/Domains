---
Color: "#6c1713"
Domain: Blood
Level: "8"
tags:
  - level8
---

##### -- Runic Adrenaline
Level: 8
Domain: Blood
Type: Ability
Recall Cost: 1
Your practice of blood magic has seeped into your bloodstream, enhancing your vitals in moments of urgency. When you roll with advantage, use a d 8 instead of a d 6 as your advantage die if you have 1 or more Hit Points marked.

After you make a Strength, an Agility, or a Finesse roll, you can mark a Hit Point to roll 1 d 8 and add it to the result.