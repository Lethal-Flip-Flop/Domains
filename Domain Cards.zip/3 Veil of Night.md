---
Color: "#434445"
Domain: Midnight
Level: "3"
tags:
  - level3
---

##### -- Veil of Night
Level: 3
Domain: Midnight
Type: Spell
Recall Cost: 1
Make a Spellcast Roll (13). On a success, you can create a temporary curtain of darkness between two points within Far range. Only you can see through this darkness. You’re considered Hidden to adversaries on the other side of the veil, and you have advantage on attacks you make through the darkness. The veil remains until you cast another spell.