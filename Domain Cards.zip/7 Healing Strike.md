---
Color: "#dabb2e"
Domain: Splendor
Level: "7"
tags:
  - level7
---

##### -- Healing Strike
Level: 7
Domain: Splendor
Type: Spell
Recall Cost: 1
When you deal damage to an adversary, you can spend 2 Hope to clear a Hit Point on an ally within Close range.