---
Color: "#dabb2e"
Domain: Splendor
Level: "9"
tags:
  - level9
---

##### -- Overwhelming Aura
Level: 9
Domain: Splendor
Type: Spell
Recall Cost: 2
Make a Spellcast Roll (15) to magically empower your aura. On a success, spend 2 Hope to make your Presence equal to your Spellcast trait until your next long rest.

While this spell is active, an adversary must mark a Stress when they target you with an attack.