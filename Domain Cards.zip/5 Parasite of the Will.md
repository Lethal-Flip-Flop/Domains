---
Color: "#6c1713"
Domain: Blood
Level: "5"
tags:
  - level5
---

##### -- Parasite of the Will
Level: 5
Domain: Blood
Type: Spell
Recall Cost: 1
Make a Spellcast Roll against a creature within Very Far range. On a success, mark a Hit Point to conjure a tiny magical bloodworm that burrows into the target. On a success with Hope, the target isn’t aware of the worm within.

You have advantage on any Presence roll against the target, and whenever they make a roll, you can spend a Hope to give the roll disadvantage. You can destroy the bloodworm to cause the target to mark a Hit Point.