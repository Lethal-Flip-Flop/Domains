---
Color: "#999b9c"
Domain: Bone
Level: "7"
tags:
  - level7
---

##### -- Cruel Precision
Level: 7
Domain: Bone
Type: Ability
Recall Cost: 1
When you make a successful attack with a weapon, gain a bonus to your damage roll equal to either your Finesse or Agility.