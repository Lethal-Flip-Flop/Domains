---
Color: "#3a3174"
Domain: Dread
Level: "8"
tags:
  - level8
---

##### -- Eldritch Flesh
Level: 8
Domain: Dread
Type: Spell
Recall Cost: 1
You embody the darkness you have dallied with. While this card is in your loadout:

- Gain a +1 bonus to your damage thresholds for each Stress you have marked.
- When you roll with Fear, you can spend 2 Hope to clear an Armor Slot.