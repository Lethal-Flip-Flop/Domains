---
Color: "#9f3630"
Domain: Blade
Level: "10"
tags:
  - level10
---

##### -- Onslaught
Level: 10
Domain: Blade
Type: Ability
Recall Cost: 3
When you successfully make an attack with your weapon, you never deal damage beneath a target’s Major damage threshold (the target always marks a minimum of 2 Hit Points).

Additionally, when a creature within your weapon’s range deals damage to an ally with an attack that doesn’t include you, you can mark a Stress to force them to make a Reaction Roll (15). On a failure, the target must mark a Hit Point.