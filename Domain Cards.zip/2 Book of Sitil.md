---
Color: "#385e8e"
Domain: Codex
Level: "2"
tags:
  - level2
---

##### -- Book of Sitil
Level: 2
Domain: Codex
Type: Grimoire
Recall Cost: 2
Adjust Appearance: You magically shift your appearance and clothing to avoid recognition.

Parallela: Spend 2 Hope to cast this spell on yourself or an ally within Close range. The next time the target makes an attack, they can hit an additional target within range that their attack roll would succeed against. You can only hold this spell on one creature at a time.

Illusion: Make a Spellcast Roll (14). On a success, create a temporary visual illusion no larger than you within Close range that lasts for as long as you look at it. It holds up to scrutiny until an observer is within Melee range.