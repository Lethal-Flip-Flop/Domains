---
Color: "#9f3630"
Domain: Blade
Level: "5"
tags:
  - level5
---

##### -- Vitality
Level: 5
Domain: Blade
Type: Ability
Recall Cost: -
When you choose this card, permanently gain two of the following benefits:

- One Stress slot
- One Hit Point slot
- +2 bonus to your damage thresholds

Then place this card in your vault permanently.