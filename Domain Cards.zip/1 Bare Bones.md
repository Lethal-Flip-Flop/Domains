---
Color: "#cd762a"
Domain: Valor
Level: "1"
tags:
  - Level1
---

##### -- Bare Bones
Level: 1 
Domain: valor
Type: Ability
Recall Cost: -
When you choose not to equip armor, you have a base Armor Score of 3 + your Strength and use the following as your base damage thresholds:

Tier 1: 9/19
Tier 2: 11/24
Tier 3: 13/31
Tier 4: 15/38
