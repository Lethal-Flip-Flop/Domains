---
Color: "#197d4a"
Domain: Sage
Level: "2"
tags:
  - level2
---

##### -- Natural Familiar
Level: 2
Domain: Sage
Type: Spell
Recall Cost: 1
Spend a Hope to summon a small nature spirit or forest critter to your side until your next rest, you cast Natural Familiar again, or the familiar is targeted by an attack. If you spend an additional Hope, you can summon a familiar that flies. You can communicate with them, make a Spellcast Roll to command them to perform simple tasks, and mark a Stress to see through their eyes.