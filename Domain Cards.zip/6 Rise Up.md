---
Color: "#cd762a"
Domain: Valor
Level: "6"
tags:
  - level6
---

##### -- Rise Up
Level: 6
Domain: Valor
Type: Ability
Recall Cost: 2
Gain a bonus to your Severe threshold equal to your Proficiency.

When you mark 1 or more Hit Points from an attack, clear a Stress.