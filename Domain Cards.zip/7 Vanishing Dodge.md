---
Color: "#434445"
Domain: Midnight
Level: "7"
tags:
  - level7
---

##### -- Vanishing Dodge
Level: 7
Domain: Midnight
Type: Spell
Recall Cost: 1
When an attack made against you that would deal physical damage fails, you can spend a Hope to envelop yourself in shadow, becoming Hidden and teleporting to a point within Close range of the attacker. You remain Hidden until the next time you make an action roll.