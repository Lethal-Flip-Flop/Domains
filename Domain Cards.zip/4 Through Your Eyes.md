---
Color: "#b03a7c"
Domain: Grace
Level: "4"
tags:
  - level4
---

##### -- Through Your Eyes
Level: 4
Domain: Grace
Type: Spell
Recall Cost: 1
Choose a target within Very Far range. You can see through their eyes and hear through their ears. You can transition between using your own senses or the target’s freely until you cast another spell or until your next rest.