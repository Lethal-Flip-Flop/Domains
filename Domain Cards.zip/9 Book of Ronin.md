---
Color: "#385e8e"
Domain: Codex
Level: "9"
tags:
  - level9
---

##### -- Book of Ronin
Level: 9
Domain: Codex
Type: Grimoire
Recall Cost: 4
Transform: Make a Spellcast Roll (15). On a success, transform into an inanimate object no larger than twice your normal size. You can remain in this shape until you take damage.

Eternal Enervation: Once per long rest, make a Spellcast Roll against a target within Close range. On a success, they become permanently Vulnerable. They can’t clear this condition by any means.