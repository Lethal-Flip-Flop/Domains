---
Color: "#9f3630"
Domain: Blade
Level: "2"
tags:
  - level2
---

##### -- A Soldier’s Bond
Level: 2
Domain: Blade
Type: Ability
Recall Cost: 1
Once per long rest, when you compliment someone or ask them about something they’re good at, you can both gain 3 Hope.