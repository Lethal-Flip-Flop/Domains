---
Color: "#9f3630"
Domain: Blade
Level: "9"
tags:
  - level9
---

##### -- Reaper's Strike
Level: 9
Domain: Blade
Type: Ability
Recall Cost: 3
Once per long rest, spend a Hope to make an attack roll. The GM tells you which targets within range it would succeed against. Choose one of these targets and force them to mark 5 Hit Points.