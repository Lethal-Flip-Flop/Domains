---
Color: "#b03a7c"
Domain: Grace
Level: "5"
tags:
  - level5
---

##### -- Thought Delver
Level: 5
Domain: Grace
Type: Spell
Recall Cost: 2
You can peek into the minds of others. Spend a Hope to read the vague surface thoughts of a target within Far range. Make a Spellcast Roll against the target to delve for deeper, more hidden thoughts.

On a roll with Fear, the target might, at the GM’s discretion, become aware that you’re reading their thoughts.