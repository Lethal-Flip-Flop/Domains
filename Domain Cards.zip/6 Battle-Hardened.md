---
Color: "#9f3630"
Domain: Blade
Level: "6"
tags:
  - level6
---

##### -- Battle-Hardened
Level: 6
Domain: Blade
Type: Ability
Recall Cost: 2
Once per long rest when you would make a Death Move, you can spend a Hope to clear a Hit Point instead.