---
Color: "#385e8e"
Domain: Codex
Level: "4"
tags:
  - level4
---

##### -- Book of Exota
Level: 4
Domain: Codex
Type: Grimoire
Recall Cost: 3
Repudiate: You can interrupt a magical effect taking place. Make a reaction roll using your Spellcast trait. Once per rest on a success, the effect stops and any consequences are avoided.

Create Construct: Spend a Hope to choose a group of objects around you and create an animated construct from them that obeys basic commands. Make a Spellcast Roll to command them to take action. When necessary, they share your Evasion and traits and their attacks deal 2 d 10+3 physical damage. You can only maintain one construct at a time, and they fall apart when they take any amount of damage.