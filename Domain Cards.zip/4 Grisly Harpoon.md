---
Color: "#6c1713"
Domain: Blood
Level: "4"
tags:
  - level4
---

##### -- Grisly Harpoon
Level: 4
Domain: Blood
Type: Spell
Recall Cost: 1
You launch a harpoon of blood at a location or creature within Far range. If the target is a location, make a Spellcast Roll (13). On a success, mark a Stress to pull yourself to a position within Melee range of it.

If the target is a creature, make a Spellcast Roll against it. On a success, mark a Stress to deal 3 d 8 magic damage to the target. You then pull the target straight toward yourself or pull yourself straight toward the target, ending within Melee range of each other.