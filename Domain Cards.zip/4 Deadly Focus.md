---
Color: "#9f3630"
Domain: Blade
Level: "4"
tags:
  - level4
---

##### -- Deadly Focus
Level: 4
Domain: Blade
Type: Ability
Recall Cost: 2
Once per rest, you can apply all your focus toward a target of your choice. Until you attack another creature, you defeat the target, or the battle ends, gain a +1 bonus to your Proficiency.

.