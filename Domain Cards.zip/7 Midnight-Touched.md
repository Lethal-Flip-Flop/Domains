---
Color: "#434445"
Domain: Midnight
Level: "7"
tags:
  - level7
---

##### -- Midnight-Touched
Level: 7
Domain: Midnight
Type: Ability
Recall Cost: 2
When 4 or more of the domain cards in your loadout are from the Midnight domain, gain the following benefits:

- Once per rest, when you have 0 Hope and the GM would gain a Fear, you can gain a Hope instead.
- When you make a successful attack, you can mark a Stress to add the result of your Fear Die to your damage roll.