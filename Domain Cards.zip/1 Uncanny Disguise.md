---
Color: "#434445"
Domain: Midnight
Level: "1"
tags:
  - Level1
---

##### -- Uncanny Disguise
Level: 1 
Domain: Midnight
Type: Spell
Recall Cost: -
When you have a few minutes to prepare, you can mark a Stress to don the facade of any humanoid you can picture clearly in your mind. While disguised, you have advantage on Presence Rolls to avoid scrutiny.

Place a number of tokens equal to your Spellcast trait on this card. When you take an action while disguised, spend a token from this card. After the action that spends the last token is resolved, the disguise drops.