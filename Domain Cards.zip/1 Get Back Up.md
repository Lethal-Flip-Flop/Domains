---
Color: "#9f3630"
Domain: Blade
Level: "1"
tags:
  - Level1
---

##### -- Get Back Up
Level: 1 
Domain: Blade
Type: Ability
Recall Cost: 1
When you take Severe damage, you can mark a Stress to reduce the severity by one threshold.