---
Color: "#895b95"
Domain: Arcana
Level: "7"
tags:
  - level7
---

##### -- Cloaking Blast
Level: 7
Domain: Arcana
Type: Spell
Recall Cost: 2
When you make a successful Spellcast Roll to cast a different spell, you can spend a Hope to become Cloaked. While Cloaked, you remain unseen if you are stationary when an adversary moves to where they would normally see you. When you move into or within an adversary’s line of sight or make an attack, you are no longer Cloaked.