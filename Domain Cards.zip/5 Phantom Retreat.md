---
Color: "#434445"
Domain: Midnight
Level: "5"
tags:
  - level5
---

##### -- Phantom Retreat
Level: 5
Domain: Midnight
Type: Ability
Recall Cost: 2
Spend a Hope to activate Phantom Retreat where you’re currently standing. Spend another Hope at any time before your next rest to disappear from where you are and reappear where you were standing when you activated Phantom Retreat. This spell ends after you reappear.