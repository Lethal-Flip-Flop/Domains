---
Color: "#999b9c"
Domain: Bone
Level: "8"
tags:
  - level8
---

##### -- Breaking Blow
Level: 8
Domain: Bone
Type: Ability
Recall Cost: 3
When you make a successful attack, you can mark a Stress to make the next successful attack against that same target deal an extra 2d12 damage.