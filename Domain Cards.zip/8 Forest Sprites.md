---
Color: "#197d4a"
Domain: Sage
Level: "8"
tags:
  - level8
---

##### -- Forest Sprites
Level: 8
Domain: Sage
Type: Spell
Recall Cost: 2
Make a Spellcast Roll (13). On a success, spend any number of Hope to create an equal number of small forest sprites who appear at points you choose within Far range, providing the following benefits:

- Your allies gain a +3 bonus to attack rolls against adversaries within Melee range of a sprite.
- An ally who marks an Armor Slot while within Melee range of a sprite can mark an additional Armor Slot.

A sprite vanishes after granting a benefit or taking any damage.