---
Color: "#3a3174"
Domain: Dread
Level: "5"
tags:
  - level5
---

##### -- Dire Strike
Level: 5
Domain: Dread
Type: Spell
Recall Cost: 1
After making a successful attack, you can spend 2 Hope to leech power from the target. For each Hit Point your target marked from this attack, the GM loses a Fear.