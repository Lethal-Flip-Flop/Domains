---
Color: "#dabb2e"
Domain: Splendor
Level: "4"
tags:
  - level4
---

##### -- Life Ward
Level: 4
Domain: Splendor
Type: Spell
Recall Cost: 1
Spend 3 Hope and choose an ally within Close range. They are marked with a glowing sigil of protection. When this ally would make a death move, they clear a Hit Point instead.

This effect ends when it saves the target from a death move, you cast Life Ward on another target, or you take a long rest.