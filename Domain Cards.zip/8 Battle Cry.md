---
Color: "#9f3630"
Domain: Blade
Level: "8"
tags:
  - level8
---

##### -- Battle Cry
Level: 8
Domain: Blade
Type: Ability
Recall Cost: 2
Once per long rest, while you’re charging into danger, you can muster a rousing call that inspires your allies. All allies who can hear you each clear a Stress and gain a Hope. Additionally, your allies gain advantage on attack rolls until you or an ally rolls a failure with Fear.