---
Color: "#cd762a"
Domain: Valor
Level: "10"
tags:
  - level10
---

##### -- Unyielding Armor
Level: 10
Domain: Valor
Type: Ability
Recall Cost: 1
When you would mark an Armor Slot, roll a number of d6s equal to your Proficiency. If any roll a 6, reduce the severity by one threshold without marking an Armor Slot.