---
Color: "#197d4a"
Domain: Sage
Level: "6"
tags:
  - level6
---

##### -- Forager
Level: 6
Domain: Sage
Type: Ability
Recall Cost: 1
As an additional downtime move you can choose, roll a d 6 to see what you forage. Work with the GM to describe it and add it to your inventory as a consumable. Your party can carry up to five foraged consumables at a time.

1. A unique food (Clear 2 Stress)
2. A beautiful relic (Gain 2 Hope)
3. An arcane rune (+2 to a Spellcast Roll)
4. A healing vial (Clear 2 Hit Points)
5. A luck charm (Reroll any die)
6. Choose one of the options above.