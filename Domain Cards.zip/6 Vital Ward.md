---
Color: "#6c1713"
Domain: Blood
Level: "6"
---
#level6
##### -- Vital Ward
Level: 6
Domain: Blood
Type: Spell
Recall Cost: 1
Mark a Hit Point to trace a circle of blood around yourself at Very Close range. While in the circle, you have resistance to your choice of physical or magic damage (choose when you cast the spell). Allies also gain this benefit while in the circle. The circle disappears if you move out of it, mark 2 or more Hit Points, or cast this spell again.