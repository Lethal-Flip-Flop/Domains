---
Color: "#dabb2e"
Domain: Splendor
Level: "3"
tags:
  - level3
---

##### -- Second Wind
Level: 3
Domain: Splendor
Type: Ability
Recall Cost: 2
Once per rest, when you succeed on an attack against an adversary, you can clear 3 Stress or a Hit Point. On a success with Hope, you also clear 3 Stress or a Hit Point on an ally within Close range of you.