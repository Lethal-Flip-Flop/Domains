---
Color: "#385e8e"
Domain: Codex
Level: "3"
tags:
  - level3
---

##### -- Book of Norai
Level: 3
Domain: Codex
Type: Grimoire
Recall Cost: 2
Mystic Tether: Make a Spellcast Roll against a target within Far range. On a success, they’re temporarily Restrained and must mark a Stress. If you target a flying creature, this spell grounds and temporarily Restrains them.

Fireball: Make a Spellcast Roll against a target within Very Far range. On a success, hurl a sphere of fire toward them that explodes on impact. The target and all creatures within Very Close range of them must make a Reaction Roll (13). Targets who fail take d 20+5 magic damage using your Proficiency. Targets who succeed take half damage.