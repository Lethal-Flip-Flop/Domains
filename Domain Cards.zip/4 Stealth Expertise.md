---
Color: "#434445"
Domain: Midnight
Level: "4"
tags:
  - level4
---

##### -- Stealth Expertise
Level: 4
Domain: Midnight
Type: Ability
Recall Cost: 0
When you roll with Fear while attempting to move unnoticed through a dangerous area, you can mark a Stress to roll with Hope instead.

If an ally within Close range is also attempting to move unnoticed and rolls with Fear, you can mark a Stress to change their result to a roll with Hope.