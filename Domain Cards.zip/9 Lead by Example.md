---
Color: "#cd762a"
Domain: Valor
Level: "9"
tags:
  - level9
---

##### -- Lead by Example
Level: 9
Domain: Valor
Type: Ability
Recall Cost: 3
When you deal damage to an adversary, you can mark a Stress and describe how you encourage your allies. The next PC to make an attack against that adversary can clear a Stress or gain a Hope.