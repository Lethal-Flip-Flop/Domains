---
Color: "#dabb2e"
Domain: Splendor
Level: "6"
tags:
  - level6
---

##### -- Restoration
Level: 6
Domain: Splendor
Type: Spell
Recall Cost: 2
After a long rest, place a number of tokens equal to your Spellcast trait on this card. Touch a creature and spend any number of tokens to clear 2 Hit Points or 2 Stress for each token spent.

You can also spend a token from this card when touching a creature to clear the Vulnerable condition or heal a physical or magical ailment (the GM might require additional tokens depending on the strength of the ailment).

When you take a long rest, clear all unspent tokens.