---
Color: "#b03a7c"
Domain: Grace
Level: "9"
tags:
  - level9
---

##### -- Master of the Craft
Level: 9
Domain: Grace
Type: Ability
Recall Cost: -
Gain a permanent +2 bonus to two of your Experiences or a permanent +3 bonus to one of your Experiences. Then place this card in your vault permanently.