---
Color: "#b03a7c"
Domain: Grace
Level: "6"
tags:
  - level6
---

##### -- Share the Burden
Level: 6
Domain: Grace
Type: Spell
Recall Cost: -
Once per rest, take on the Stress from a willing creature within Melee range. The target describes what intimate knowledge or emotions telepathically leak from their mind in this moment between you. Transfer any number of their marked Stress to you, then gain a Hope for each Stress transferred.