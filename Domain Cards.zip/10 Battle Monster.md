---
Color: "#9f3630"
Domain: Blade
Level: "10"
tags:
  - level10
---

##### -- Battle Monster
Level: 10
Domain: Blade
Type: Ability
Recall Cost: 0
When you make a successful attack against an adversary, you can mark 4 Stress to force the target to mark a number of Hit Points equal to the number of Hit Points you currently have marked instead of rolling for damage.