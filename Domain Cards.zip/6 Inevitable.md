---
Color: "#cd762a"
Domain: Valor
Level: "6"
tags:
  - level6
---

##### -- Inevitable
Level: 6
Domain: Valor
Type: Ability
Recall Cost: 1
When you fail an action roll, your next action roll has advantage.