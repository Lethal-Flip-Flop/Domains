---
Color: "#434445"
Domain: Midnight
Level: "5"
tags:
  - level5
---

##### -- Hush
Level: 5
Domain: Midnight
Type: Ability
Recall Cost: 1
Make a Spellcast Roll against a target within Close range. On a success, spend a Hope to conjure suppressive magic around the target that encompasses everything within Very Close range of them and follows them as they move.

The target and anything within the area is Silenced until the GM spends a Fear on their turn to clear this condition, you cast Hush again, or you take Major damage. While Silenced, they can’t make noise and can’t cast spells.
