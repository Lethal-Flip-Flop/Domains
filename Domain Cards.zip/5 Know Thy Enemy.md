---
Color: "#999b9c"
Domain: Bone
Level: "5"
tags:
  - level5
---

##### -- Know Thy Enemy
Level: 5
Domain: Bone
Type: Ability
Recall Cost: 1
When observing a creature, you can make an Instinct Roll against them. On a success, spend a Hope and ask the GM for one set of information about the target from the following options:

- Their unmarked Hit Points and Stress.
- Their Difficulty and damage thresholds.
- Their tactics and standard attack damage dice.
- Their features and Experiences.

Additionally on a success, you can mark a Stress to remove a Fear from the GM’s Fear Pool.