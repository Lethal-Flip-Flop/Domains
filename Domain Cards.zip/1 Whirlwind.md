---
Color: "#9f3630"
Domain: Blade
Level: "1"
tags:
  - Level1
---

##### -- Whirlwind
Level: 1 
Domain: Blade
Type: Ability
Recall Cost: -
When you make a successful attack against a target within Very Close range, you can spend a Hope to use the attack against all other targets within Very Close range. All additional adversaries you succeed against with this ability take half damage.