---
Color: "#999b9c"
Domain: Bone
Level: "1"
tags:
  - Level1
---

##### -- Untouchable
Level: 1 
Domain: Bone
Type: Ability
Recall Cost: 1
Gain a bonus to your Evasion equal to half your Agility.