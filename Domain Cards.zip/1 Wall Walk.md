---
Color: "#895b95"
Domain: Arcana
Level: "1"
tags:
  - Level1
---

##### -- Wall Walk
Level: 1 
Domain: Arcana
Type: Spell
Recall Cost: 1
Spend a Hope to allow a creature you can touch to climb on walls and ceilings as easily as walking on the ground. This lasts until the end of the scene or you cast Wall Walk again.