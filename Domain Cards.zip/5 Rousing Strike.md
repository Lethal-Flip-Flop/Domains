---
Color: "#cd762a"
Domain: Valor
Level: "5"
tags:
  - level5
---

##### -- Rousing Strike
Level: 5
Domain: Valor
Type: Ability
Recall Cost: 1
Once per rest, when you critically succeed on an attack, you and all allies who can see or hear you can clear a Hit Point or 1d4 Stress.