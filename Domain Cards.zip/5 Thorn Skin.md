---
Color: "#197d4a"
Domain: Sage
Level: "5"
tags:
  - level5
---

##### -- Thorn Skin
Level: 5
Domain: Sage
Type: Spell
Recall Cost: 1
Once per rest, spend a Hope to sprout thorns all over your body. When you do, place a number of tokens equal to your Spellcast trait on this card. When you take damage, you can spend any number of tokens to roll that number of d 6 s. Add the results together and reduce the incoming damage by that amount. If you’re within Melee range of the attacker, deal that amount of damage back to them.

When you take a rest, clear all unspent tokens.