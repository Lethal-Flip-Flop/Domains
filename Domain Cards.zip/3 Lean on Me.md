---
Color: "#cd762a"
Domain: Valor
Level: "3"
tags:
  - level3
---

##### -- Lean on Me
Level: 3
Domain: Valor
Type: Ability
Recall Cost: 1
Once per long rest, when you console or inspire an ally who failed an action roll, you can both clear 2 Stress.