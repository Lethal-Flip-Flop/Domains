---
Color: "#3a3174"
Domain: Dread
Level: "9"
tags:
  - level9
---

##### -- Savor the Anguish
Level: 9
Domain: Dread
Type: Spell
Recall Cost: -
Whenever an adversary within Close range marks Stress or takes Severe damage, you can spend a Hope to clear a Stress or force the GM to lose a Fear.