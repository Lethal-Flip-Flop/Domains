---
Color: "#895b95"
Domain: Arcana
Level: "6"
tags:
  - level6
---

##### -- Telekinesis
Level: 6
Domain: Arcana
Type: Spell
Recall Cost: -
Make a Spellcast Roll against a target within Far range. On a success, you can use your mind to move them anywhere within Far range of their original position. You can throw the lifted target as an attack by making an additional Spellcast Roll against the second target you’re trying to attack. On a success, deal d12+4 physical damage to the second target using your Proficiency. This spell then ends.