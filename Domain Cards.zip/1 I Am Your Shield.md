---
Color: "#cd762a"
Domain: Valor
Level: "1"
tags:
  - Level1
---

##### -- I Am Your Shield
Level: 1 
Domain: Valor
Type: Ability
Recall Cost: 1
When an ally within Very Close range would take damage, you can mark a Stress to stand in the way and make yourself the target of the attack instead. When you take damage from this attack, you can mark any number of Armor Slots.