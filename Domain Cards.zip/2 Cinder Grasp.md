---
Color: "#895b95"
Domain: Arcana
Level: "2"
tags:
  - level2
---

##### -- Cinder Grasp
Level: 2
Domain: Arcana
Type: Spell
Recall Cost: 1
Make a Spellcast Roll against a target within Melee range. On a success, the target instantly bursts into flames, takes 1 d 20+3 magic damage, and is temporarily lit On Fire.

When a creature acts while On Fire, they must take an extra 2 d 6 magic damage if they are still On Fire at the end of their action.