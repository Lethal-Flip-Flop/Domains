---
Color: "#385e8e"
Domain: Codex
Level: "7"
tags:
  - level7
---

##### -- Codex-Touched
Level: 7
Domain: Codex
Type: Ability
Recall Cost: 2
When 4 or more of the domain cards in your loadout are from the Codex domain, gain the following benefits:

You can mark a Stress to add your Proficiency to a Spellcast Roll.
Once per rest, replace this card with any card from your vault without paying its Recall Cost.