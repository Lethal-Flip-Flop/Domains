---
Color: "#3a3174"
Domain: Dread
Level: "7"
tags:
  - level7
---

##### -- Dread-Touched
Level: 7
Domain: Dread
Type: Spell
Recall Cost: 2
When 4 or more of the domain cards in your loadout are from the Dread domain, gain the following benefits:

- When you succeed with Fear, you can mark 2 Stress to prevent the GM from gaining a Fear.
- Once per rest, when making an action roll, you can add a +1 bonus to the roll for each Fear token the GM has stored.