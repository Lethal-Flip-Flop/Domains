---
Color: "#197d4a"
Domain: Sage
Level: "4"
tags:
  - level4
---

##### -- Death Grip
Level: 4
Domain: Sage
Type: Spell
Recall Cost: 1
Make a Spellcast Roll against a target within Close range and choose one of the following options:

You pull the target into Melee range or pull yourself into Melee range of them.
You constrict the target and force them to mark 2 Stress.
All adversaries between you and the target must succeed on a Reaction Roll (13) or be hit by vines, taking 3 d 6+2 physical damage.
On a success, vines reach out from your hands, causing the chosen effect and temporarily Restraining the target.