---
Color: "#434445"
Domain: Midnight
Level: "4"
tags:
  - level4
---

##### -- Glyph of Nightfall
Level: 4
Domain: Midnight
Type: Spell
Recall Cost: 1 
Make a Spellcast Roll against a target within Very Close range. On a success, spend a Hope to conjure a dark glyph upon their body that exposes their weak points, temporarily reducing the target’s Difficulty by a value equal to your Knowledge (minimum 1).