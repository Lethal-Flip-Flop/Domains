---
Color: "#895b95"
Domain: Arcana
Level: "1"
tags:
  - Level1
---

##### -- Rune Ward
Level: 1 
Domain: Arcana
Type: Spell
Recall Cost: -
You have a deeply personal trinket that can be infused with protective magic and held as a ward by you or an ally. Describe what it is and why it’s important to you. The ward’s holder can spend a Hope to reduce incoming damage by 1 d 8.

If the Ward Die result is 8, the ward’s power ends after it reduces damage this turn. It can be recharged for free on your next rest.