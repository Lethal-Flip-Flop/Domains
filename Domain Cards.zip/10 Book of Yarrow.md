---
Color: "#385e8e"
Domain: Codex
Level: "10"
tags:
  - level10
---

##### -- Book of Yarrow
Level: 10
Domain: Codex
Type: Grimoire
Recall Cost: 2
Timejammer: Make a Spellcast Roll (18). On a success, time temporarily slows to a halt for everyone within Far range except for you. It resumes the next time you make an action roll that targets another creature.

Magic Immunity: Spend 5 Hope to become immune to magic damage until your next rest.