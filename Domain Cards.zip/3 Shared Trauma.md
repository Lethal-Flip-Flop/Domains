---
Color: "#3a3174"
Domain: Dread
Level: "3"
tags:
  - level3
---

##### -- Shared Trauma
Level: 3
Domain: Dread
Type: Spell
Recall Cost: 1
 You can transfer suffering from one creature to another. Once per rest, mark any number of Hit Points on a willing creature within Melee range to clear an equal number of Hit Points on another willing creature within Melee range. You can choose yourself in place of either creature.