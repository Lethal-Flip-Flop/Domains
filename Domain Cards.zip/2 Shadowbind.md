---
Color: "#434445"
Domain: Midnight
Level: "2"
tags:
  - level2
---

##### -- Shadowbind
Level: 2
Domain: Midnight
Type: Spell
Recall Cost: -
Make a Spellcast Roll against all adversaries within Very Close range. Targets you succeed against are temporarily Restrained as their shadow binds them in place.