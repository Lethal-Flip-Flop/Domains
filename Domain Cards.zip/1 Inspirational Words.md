---
Color: "#b03a7c"
Domain: Grace
Level: "1"
tags:
  - Level1
---

##### -- Inspirational Words
Level: 1 
Domain: grace
Type: Ability
Recall Cost: 1
Your speech is imbued with power. After a long rest, place a number of tokens on this card equal to your Presence. When you speak with an ally, you can spend a token from this card to give them one benefit from the following options:

- Your ally clears a Stress.
- Your ally clears a Hit Point.
- Your ally gains a Hope.

When you take a long rest, clear all unspent tokens.