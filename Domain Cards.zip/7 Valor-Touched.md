---
Color: "#cd762a"
Domain: Valor
Level: "7"
tags:
  - level7
---

##### -- Valor-Touched
Level: 7
Domain: Valor
Type: Ability
Recall Cost: 1
When 4 or more of the domain cards in your loadout are from the Valor domain, gain the following benefits:

+1 bonus to your Armor Score
When you mark 1 or more Hit Points without marking an Armor Slot, clear an Armor Slot.