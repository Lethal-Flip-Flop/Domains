---
Color: "#3a3174"
Domain: Dread
Level: "4"
tags:
  - level4
---

##### -- Summon Horror
Level: 4
Domain: Dread
Type: Spell
Recall Cost: 2
Make a Spellcast Roll against a target within Far range. On a success, spend a Hope to call forth an otherworldly creature to attack them and deal d 10 magic damage using your Proficiency. The target must succeed on a Reaction Roll (12) to steel themselves from the horror or mark 1 d 4 Stress.

After making the attack, the creature dissipates.