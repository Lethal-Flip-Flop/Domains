---
Color: "#9f3630"
Domain: Blade
Level: "3"
tags:
  - level3
---

##### -- Versatile Fighter
Level: 3
Domain: Blade
Type: Ability
Recall Cost: 1
You can use a different character trait for an equipped weapon, rather than the trait the weapon calls for.

When you deal damage, you can mark a Stress to use the maximum result of one of your damage dice instead of rolling it.