---
Color: "#895b95"
Domain: Arcana
Level: "5"
tags:
  - level5
---

##### -- Chain Lightning
Level: 5
Domain: Arcana
Type: Spell
Recall Cost: 1
Mark 2 Stress to make a Spellcast Roll, unleashing lightning on all targets within Close range. Targets you succeed against must make a reaction roll with a Difficulty equal to the result of your Spellcast Roll. Targets who fail take 2d8+4 magic damage. Additional adversaries not already targeted by Chain Lightning and within Close range of previous targets who took damage must also make the reaction roll. Targets who fail take 2d8+4 magic damage. This chain continues until there are no more adversaries within range.