---
Color: "#895b95"
Domain: Arcana
Level: "6"
tags:
  - level6
---

##### -- Rift Walker
Level: 6
Domain: Arcana
Type: Spell
Recall Cost: 2
Make a Spellcast Roll (15). On a success, you place an arcane marking on the ground where you currently stand. The next time you successfully cast Rift Walker, a rift in space opens up, providing safe passage back to the exact spot where the marking was placed. This rift stays open until you choose to close it or you cast another spell.

You can drop the spell at any time to cast Rift Walker again and place the marking somewhere new.