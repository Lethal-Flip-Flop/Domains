---
Color: "#385e8e"
Domain: Codex
Level: "2"
tags:
  - level2
---

##### -- Book of Vagras
Level: 2
Domain: Codex
Type: Grimoire
Recall Cost: 2
Runic Lock: Make a Spellcast Roll (15) on an object you’re touching that can close (such as a lock, chest, or box). Once per rest on a success, you can lock the object so it can only be opened by creatures of your choice. Someone with access to magic and an hour of time to study the spell can break it.

Arcane Door: When you have no adversaries within Melee range, make a Spellcast Roll (13). On a success, spend a Hope to create a portal from where you are to a point within Far range you can see. It closes once a creature has passed through it.

Reveal: Make a Spellcast Roll. If there is anything magically hidden within Close range the roll would succeed against, it is revealed.