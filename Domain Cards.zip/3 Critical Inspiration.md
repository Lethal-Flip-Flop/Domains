---
Color: "#cd762a"
Domain: Valor
Level: "3"
tags:
  - level3
---

##### -- Critical Inspiration
Level: 3
Domain: Valor
Type: Ability
Recall Cost: 1
Once per rest, when you critically succeed on an attack, all allies within Very Close range can clear a Stress or gain a Hope.