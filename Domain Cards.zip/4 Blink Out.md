---
Color: "#895b95"
Domain: Arcana
Level: "4"
tags:
  - level4
---

##### -- Blink Out
Level: 4
Domain: Arcana
Type: Spell
Recall Cost: 1
Make a Spellcast Roll (12). On a success, spend a Hope to teleport to another point you can see within Far range. If any willing creatures are within Very Close range, spend an additional Hope for each creature to bring them with you.