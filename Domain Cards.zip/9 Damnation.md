---
Color: "#3a3174"
Domain: Dread
Level: "9"
tags:
  - level9
---

##### -- Damnation
Level: 9
Domain: Dread
Type: Spell
Recall Cost: 2
Make a Spellcast Roll against a target within Far range. On a success, mark any number of Stress to roll an equal number of d20s, dealing magic damage equal to the total result. If the target is defeated as a result of this attack, all adversaries within Far range of the target mark a Stress.