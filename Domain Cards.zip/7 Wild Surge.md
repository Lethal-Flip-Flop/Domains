---
Color: "#197d4a"
Domain: Sage
Level: "7"
tags:
  - level7
---

##### -- Wild Surge
Level: 7
Domain: Sage
Type: Spell
Recall Cost: 2
Once per long rest, mark a Stress to channel the natural world around you and enhance yourself. Describe how your appearance changes, then place a d 6 on this card with the 1 value facing up.

While the Wild Surge Die is active, you add its value to every action roll you make. After you add its value to a roll, increase the Wild Surge Die’s value by one. When the die’s value would exceed 6 or you take a rest, this form drops and you must mark an additional Stress.