---
Color: "#434445"
Domain: Midnight
Level: "10"
tags:
  - level10
---

##### -- Eclipse
Level: 10
Domain: Midnight
Type: Spell
Recall Cost: 2
Make a Spellcast Roll (16). Once per long rest on a success, plunge the entire area within Far range into complete darkness only you and your allies can see through. Attack rolls have disadvantage when targeting you or an ally within this shadow.

Additionally, when you or an ally succeeds with Hope against an adversary within this shadow, the target must mark a Stress.

This spell lasts until the GM spends a Fear on their turn to clear this effect or you take Severe damage.