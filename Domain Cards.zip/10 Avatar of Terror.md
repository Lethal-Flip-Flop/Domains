---
Color: "#3a3174"
Domain: Dread
Level: "10"
tags:
  - level10
---

##### -- Avatar of Terror
Level: 10
Domain: Dread
Type: Spell
Recall Cost: 1
Mark a Stress to transform into a creature fueled by fear. While in this form, your damage rolls gain a +1 d 6 bonus for each Fear the GM has. Additionally, gain a Hope when the GM uses a Fear feature on an adversary within Close range.

You must spend a Hope to make an action roll while in this form. Otherwise, you drop out of this form.