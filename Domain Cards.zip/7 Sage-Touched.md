---
Color: "#197d4a"
Domain: Sage
Level: "7"
tags:
  - level7
---

##### -- Sage-Touched
Level: 7
Domain: Sage
Type: Ability
Recall Cost: 2
When 4 or more of the domain cards in your loadout are from the Sage domain, gain the following benefits:

- While you’re in a natural environment, you gain a +2 bonus to your Spellcast Rolls.
- Once per rest, you can double your Agility or Instinct when making a roll that uses that trait. You must choose to do this before you roll.