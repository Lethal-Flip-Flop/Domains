---
Color: "#385e8e"
Domain: Codex
Level: "7"
tags:
  - level7
---

##### -- Book of Homet
Level: 7
Domain: Codex
Type: Grimoire
Recall Cost: -
Pass Through: Make a Spellcast Roll (13). Once per rest on a success, you and all creatures touching you can pass through a wall or door within Close range. The effect ends once everyone is on the other side.

Plane Gate: Make a Spellcast Roll (14). Once per long rest on a success, open a gateway to a location in another dimension or plane of existence you’ve been to before. This gateway lasts until your next rest.