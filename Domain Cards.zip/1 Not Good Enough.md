---
Color: "#9f3630"
Domain: Blade
Level: "1"
tags:
  - Level1
---

##### -- Not Good Enough
Level: 1 
Domain: Blade
Type: Ability
Recall Cost: 1
When you roll your damage dice, you can reroll any 1s or 2s.