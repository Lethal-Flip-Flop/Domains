---
Color: "#dabb2e"
Domain: Splendor
Level: "7"
tags:
  - level7
---

##### -- Splendor-Touched
Level: 7
Domain: Splendor
Type: Ability
Recall Cost: 2
When 4 or more of the domain cards in your loadout are from the Splendor domain, gain the following benefits:

+3 bonus to your Severe damage threshold
Once per long rest, when incoming damage would require you to mark a number of Hit Points, you can choose to mark that much Stress or spend that much Hope instead.