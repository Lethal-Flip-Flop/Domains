---
Color: "#999b9c"
Domain: Bone
Level: "1"
tags:
  - Level1
---

##### -- I See It Coming
Level: 1 
Domain: Bone
Type: Ability
Recall Cost: 1
When you’re targeted by an attack made from beyond Melee range, you can mark a Stress to roll a d 4 and gain a bonus to your Evasion equal to the result against the attack.