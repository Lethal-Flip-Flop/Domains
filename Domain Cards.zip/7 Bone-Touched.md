---
Color: "#999b9c"
Domain: Bone
Level: "7"
tags:
  - level7
---

##### -- Bone-Touched
Level: 7
Domain: Bone
Type: Ability
Recall Cost: 2
When 4 or more of the domain cards in your loadout are from the Bone domain, gain the following benefits:

- +1 bonus to Agility
- Once per rest, you can spend 3 Hope to cause an attack that succeeded against you to fail instead.