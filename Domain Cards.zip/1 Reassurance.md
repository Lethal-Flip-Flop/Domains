---
Color: "#dabb2e"
Domain: Splendor
Level: "1"
tags:
  - Level1
---

##### -- Reassurance
Level: 1 
Domain: Splendor
Type: Ability
Recall Cost: -
Once per rest, after an ally attempts an action roll but before the consequences take place, you can offer assistance or words of support. When you do, your ally can reroll their dice.