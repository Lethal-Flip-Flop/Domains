---
Color: "#6c1713"
Domain: Blood
Level: "10"
tags:
  - level10
---

##### -- Crimson Adamance
Level: 10
Domain: Blood
Type: Ability
Recall Cost: 1
When you would mark your last Hit Point, spend a Hope to mark a Stress instead.