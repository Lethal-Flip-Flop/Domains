---
Color: "#dabb2e"
Domain: Splendor
Level: "2"
tags:
  - level2
---

##### -- Healing Hands
Level: 2
Domain: Splendor
Type: Spell
Recall Cost: 1
Make a Spellcast Roll (13) and target a creature other than yourself within Melee range. On a success, mark a Stress to clear 2 Hit Points or 2 Stress on the target. On a failure, mark a Stress to clear a Hit Point or a Stress on the target. You can’t heal the same target again until your next long rest.