---
Color: "#895b95"
Domain: Arcana
Level: "2"
tags:
  - level2
---

##### -- Floating Eye
Level: 2
Domain: Arcana
Type: Spell
Recall Cost: -
Spend a Hope to create a single, small floating orb that you can move anywhere within Very Far range. While this spell is active, you can see through the orb as though you’re looking out from its position. You can transition between using your own senses and seeing through the orb freely. If the orb takes damage or moves out of range, the spell ends.