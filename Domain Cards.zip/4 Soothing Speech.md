---
Color: "#b03a7c"
Domain: Grace
Level: "4"
tags:
  - level4
---

##### -- Soothing Speech
Level: 4
Domain: Grace
Type: Ability
Recall Cost: 1
During a short rest, when you take the time to comfort another character while using the Tend to Wounds downtime move on them, clear an additional Hit Point on that character. When you do, you also clear 2 Hit Points.