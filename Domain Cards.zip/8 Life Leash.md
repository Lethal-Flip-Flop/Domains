---
Color: "#6c1713"
Domain: Blood
Level: "8"
tags:
  - level8
---

##### -- Life Leash
Level: 8
Domain: Blood
Type: Spell
Recall Cost: 2
Spend a Hope to allow yourself and a willing ally within Far range to redistribute marked Hit Points between the two of you. You then can’t target that ally again with Life Leash until you finish a rest.