---
Color: "#999b9c"
Domain: Bone
Level: "9"
tags:
  - level9
---

##### -- On the Brink
Level: 9
Domain: Bone
Type: Ability
Recall Cost: 1
When you have 2 or fewer Hit Points unmarked, you don’t take Minor damage.