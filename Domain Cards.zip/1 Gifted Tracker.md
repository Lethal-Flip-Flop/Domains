---
Color: "#197d4a"
Domain: Sage
Level: "1"
tags:
  - Level1
---

##### -- Gifted Tracker
Level: 1 
Domain: Sage
Type: Ability
Recall Cost: -
When you’re tracking a specific creature or group of creatures based on signs of their passage, you can spend any number of Hope and ask the GM that many questions from the following list.

- What direction did they go?
- How long ago did they pass through?
- What were they doing in this location?
- How many of them were here?

When you encounter creatures you’ve tracked in this way, gain a +1 bonus to your Evasion against them.