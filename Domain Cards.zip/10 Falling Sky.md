---
Color: "#895b95"
Domain: Arcana
Level: "10"
tags:
  - level10
---

##### -- Falling Sky
Level: 10
Domain: Arcana
Type: Spell
Recall Cost: 1
Make a Spellcast Roll against all adversaries within Far range. Mark any number of Stress to make shards of arcana rain down from above. Targets you succeed against take 1d20+2 magic damage for each Stress marked.