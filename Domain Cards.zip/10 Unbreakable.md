---
Color: "#cd762a"
Domain: Valor
Level: "10"
tags:
  - level10
---

##### -- Unbreakable
Level: 10
Domain: Valor
Type: Ability
Recall Cost: 4
When you mark your last Hit Point, instead of making a death move, you can roll a d6 and clear a number of Hit Points equal to the result. Then place this card in your vault.