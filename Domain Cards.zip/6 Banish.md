---
Color: "#385e8e"
Domain: Codex
Level: "6"
tags:
  - level6
---

##### -- Banish
Level: 6
Domain: Codex
Type: Spell
Recall Cost: -
Make a Spellcast Roll against a target within Close range. On a success, roll a number of d 20 s equal to your Spellcast trait. The target must make a reaction roll with a Difficulty equal to your highest result. On a success, the target must mark a Stress but isn’t banished. Once per rest on a failure, they are banished from this realm.

When the PCs roll with Fear, the Difficulty gains a −1 penalty and the target makes another reaction roll. On a success, they return from banishment.