---
Color: "#3a3174"
Domain: Dread
Level: "4"
tags:
  - level4
---

##### -- Chains of Affliction
Level: 4
Domain: Dread
Type: Spell
Recall Cost: 2
Mark 2 Stress to temporarily Chain a target within Close range. When a Chained creature deals damage, the target of their attack reduces the number of Hit Points they mark by one. You can't have more than one creature Chained at a time.