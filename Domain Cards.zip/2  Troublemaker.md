---
Color: "#b03a7c"
Domain: Grace
Level: "2"
tags:
  - level2
---

##### -- Troublemaker
Level: 2
Domain: Grace
Type: Ability
Recall Cost: 2
When you taunt or provoke a target within Far range, make a Presence Roll against them. Once per rest on a success, roll a number of d4s equal to your Proficiency. The target must mark Stress equal to the highest result rolled.