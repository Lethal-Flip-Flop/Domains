---
Color: "#434445"
Domain: Midnight
Level: "2"
tags:
  - level2
---

##### -- Midnight Spirit
Level: 2
Domain: Midnight
Type: Spell
Recall Cost: 1
Spend a Hope to summon a humanoid-sized spirit that can move or carry things for you until your next rest.

You can also send it to attack an adversary. When you do, make a Spellcast Roll against a target within Very Far range. On a success, the spirit moves into Melee range with that target. Roll a number of d 6 s equal to your Spellcast trait and deal that much magic damage to the target. The spirit then dissipates. You can only have one spirit at a time.