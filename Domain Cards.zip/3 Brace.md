---
Color: "#999b9c"
Domain: Bone
Level: "3"
tags:
  - level3
---

##### -- Brace
Level: 3
Domain: Bone
Type: Ability
Recall Cost: 1
When you mark an Armor Slot to reduce incoming damage, you can mark a Stress to mark an additional Armor Slot.