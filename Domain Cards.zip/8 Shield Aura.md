---
Color: "#dabb2e"
Domain: Splendor
Level: "8"
tags:
  - level8
---

##### -- Shield Aura
Level: 8
Domain: Splendor
Type: Spell
Recall Cost: 2
Mark a Stress to cast a protective aura on a target within Very Close range. When the target marks an Armor Slot, they reduce the severity of the attack by an additional threshold. If this spell causes a creature who would be damaged to instead mark no Hit Points, the effect ends.

You can only hold Shield Aura on one creature at a time.