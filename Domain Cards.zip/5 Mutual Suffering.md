---
Color: "#6c1713"
Domain: Blood
Level: "5"
tags:
  - level5
---

##### -- Mutual Suffering
Level: 5
Domain: Blood
Type: Spell
Recall Cost: 1
When an attack from a creature causes you to mark one or more Hit Points, you can make a Reaction Roll using your Spellcast trait against the creature. On a success, the creature marks the same number of Hit Points as you did, and you can’t use this spell again until you finish a rest.