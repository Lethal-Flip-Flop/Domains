---
Color: "#197d4a"
Domain: Sage
Level: "1"
tags:
  - Level1
---

##### -- Nature's Tongue
Level: 1 
Domain: Sage
Type: Ability
Recall Cost: -
You can speak the language of the natural world. When you want to speak to the plants and animals around you, make an Instinct Roll (12). On a success, they’ll give you the information they know. On a roll with Fear, their knowledge might be limited or come at a cost.

Additionally, before you make a Spellcast Roll while within a natural environment, you can spend a Hope to gain a +2 bonus to the roll.