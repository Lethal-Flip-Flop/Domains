---
Color: "#895b95"
Domain: Arcana
Level: "4"
tags:
  - level4
---

##### -- Preservation Blast
Level: 4
Domain: Arcana
Type: Spell
Recall Cost: 2
Make a Spellcast Roll against all targets within Melee range. Targets you succeed against are forced back to Far range and take d8+3 magic damage using your Spellcast trait.