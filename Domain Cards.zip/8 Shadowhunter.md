---
Color: "#434445"
Domain: Midnight
Level: "8"
---

##### -- Shadowhunter
Level: 8
Domain: Midnight
Type: Ability
Recall Cost: 2
Your prowess is enhanced under the cover of shadow. While you’re shrouded in low light or darkness, you gain a +1 bonus to your Evasion and make attack rolls with advantage.