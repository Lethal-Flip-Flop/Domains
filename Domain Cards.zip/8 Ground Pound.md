---
Color: "#cd762a"
Domain: Valor
Level: "8"
tags:
  - level8
---

##### -- Ground Pound
Level: 8
Domain: Valor
Type: Ability
Recall Cost: 2
Spend 2 Hope to strike the ground where you stand and make a Strength Roll against all targets within Very Close range. Targets you succeed against are thrown back to Far range and must make a Reaction Roll (17). Targets who fail take 4d10+8 damage. Targets who succeed take half damage.