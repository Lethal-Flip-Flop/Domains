---
Color: "#dabb2e"
Domain: Splendor
Level: "5"
tags:
  - level5
---

##### -- Smite
Level: 5
Domain: Splendor
Type: Spell
Recall Cost: 2
Once per rest, spend 3 Hope to charge your powerful smite. When you next successfully attack with a weapon, double the result of your damage roll. This attack deals magic damage regardless of the weapon’s damage type.