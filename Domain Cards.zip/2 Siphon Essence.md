---
Color: "#3a3174"
Domain: Dread
Level: "2"
tags:
  - level2
---

##### -- Siphon Essence
Level: 2
Domain: Dread
Type: Spell
Recall Cost: 1
Make a Spellcast Roll against a target within Very Close range. On a success, once per long rest, the target takes d20 magic damage using your Proficiency. You clear a number of Hit Points equal to the number of Hit Points the target marked from this attack. On a success with Fear, you gain a +1 bonus to your Proficiency for this attack.