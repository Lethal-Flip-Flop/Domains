---
Color: "#385e8e"
Domain: Codex
Level: "3"
tags:
  - level3
---

##### -- Book of Korvax
Level: 3
Domain: Codex
Type: Grimoire
Recall Cost: 2
Levitation: Make a Spellcast Roll to temporarily lift a target you can see up into the air and move them within Close range of their original position.

Recant: Spend a Hope to force a target within Melee range to make a Reaction Roll (15). On a failure, they forget the last minute of your conversation.

Rune Circle: Mark a Stress to create a temporary magical circle on the ground where you stand. All adversaries within Melee range, or who enter Melee range, take 2 d 12+4 magic damage and are knocked back to Very Close range.