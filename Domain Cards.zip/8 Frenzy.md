---
Color: "#9f3630"
Domain: Blade
Level: "8"
tags:
  - level8
---

##### -- Frenzy
Level: 8
Domain: Blade
Type: Ability
Recall Cost: 3
Once per long rest, you can go into a Frenzy until there are no more adversaries within sight.

While Frenzied, you can’t use Armor Slots, and you gain a +10 bonus to your damage rolls and a +8 bonus to your Severe damage threshold.