---
Color: "#b03a7c"
Domain: Grace
Level: "1"
tags:
  - Level1
---

##### -- Deft Deceiver
Level: 1 
Domain: Grace
Type: Ability
Recall Cost: -
Spend a Hope to gain advantage on a roll to deceive or trick someone into believing a lie you tell them.
