---
Color: "#6c1713"
Domain: Blood
Level: "2"
tags:
  - level2
---

##### -- Vitality Manipulation
Level: 2
Domain: Blade
Type: Spell
Recall Cost: -
Make a Spellcast Roll against a target within Very Close range. If you cast this on an ally, make the roll with advantage. On a success, mark a Stress, and choose one of the following effects:

- The target grows calmer and clears a Stress. On a success with Hope, they clear 2 Stress.
- The target grows more anxious and marks a Stress. On a success with Hope, they mark 2 Stress.