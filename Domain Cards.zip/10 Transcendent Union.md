---
Color: "#385e8e"
Domain: Codex
Level: "10"
tags:
  - level10
---

##### -- Transcendent Union
Level: 10
Domain: Codex
Type: Spell
Recall Cost: 1
Once per long rest, spend 5 Hope to cast this spell on two or more willing creatures. Until your next rest, when a creature connected by this union would mark Stress or Hit Points, the connected creatures can choose who marks it.