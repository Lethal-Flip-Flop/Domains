---
Color: "#cd762a"
Domain: Valor
Level: "8"
tags:
  - level8
---

##### -- Full Surge
Level: 8
Domain: Valor
Type: Ability
Recall Cost: 
Once per long rest, mark 3 Stress to push your body to its limits. Gain a +2 bonus to all of your character traits until your next rest.