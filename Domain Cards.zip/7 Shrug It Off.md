---
Color: "#cd762a"
Domain: Valor
Level: "7"
tags:
  - level7
---

##### -- Shrug It Off
Level: 7
Domain: Valor
Type: Ability
Recall Cost: 1
When you would take damage, you can mark a Stress to reduce the severity of the damage by one threshold. When you do, roll a d6. On a result of 3 or lower, place this card in your vault.