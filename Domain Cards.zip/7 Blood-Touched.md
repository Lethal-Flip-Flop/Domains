---
Color: "#6c1713"
Domain: Blood
Level: "7"
tags:
  - level7
---

##### -- Blood-Touched
Level: 7
Domain: Blood
Type: Ability
Recall Cost: 1
While 4 or more of the domain cards in your loadout are from the Blood domain, gain the following benefits:

- When you take enough damage to mark 2 or more Hit Points, gain a Hope.
- For every 3 Hit Points you have marked, gain a +1 bonus to your Evasion.