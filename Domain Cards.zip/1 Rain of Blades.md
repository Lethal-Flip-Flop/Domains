---
Color: "#434445"
Domain: Midnight
Level: "1"
tags:
  - Level1
---

##### -- Rain of Blades
Level: 1 
Domain: Midnight
Type: Spell
Recall Cost: 1
Spend a Hope to make a Spellcast Roll and conjure throwing blades that strike out at all targets within Very Close range. Targets you succeed against take d 8+2 magic damage using your Proficiency.

If a target you hit is Vulnerable, they take an extra 1 d 8 damage.