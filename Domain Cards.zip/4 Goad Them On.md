---
Color: "#cd762a"
Domain: Valor
Level: "4"
tags:
  - level4
---

##### -- Goad Them On
Level: 4
Domain: Valor
Type: Ability
Recall Cost: 1
Describe how you taunt a target within Close range, then make a Presence Roll against them. On a success, the target must mark a Stress, and the next time the GM spotlights them, they must target you with an attack, which they make with disadvantage.