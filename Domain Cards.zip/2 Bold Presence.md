---
Color: "#cd762a"
Domain: Valor
Level: "2"
tags:
  - level2
---

##### -- Bold Presence
Level: 2
Domain: Valor
Type: Ability
Recall Cost: -
When you make a Presence Roll, you can spend a Hope to add your Strength to the roll.

Additionally, once per rest when you would gain a condition, you can describe how your bold presence aids you in the situation and avoid gaining the condition.