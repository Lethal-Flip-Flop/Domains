---
Color: "#dabb2e"
Domain: Splendor
Level: "6"
tags:
  - level6
---

##### -- Zone of Protection
Level: 6
Domain: Splendor
Type: Spell
Recall Cost: 2
Make a Spellcast Roll (16). Once per long rest on a success, choose a point within Far range and create a visible zone of protection there for all allies within Very Close range of that point. When you do, place a d6 on this card with the 1 value facing up. When an ally in this zone takes damage, they reduce it by the die’s value. You then increase the die’s value by one. When the die’s value would exceed 6, this effect ends.