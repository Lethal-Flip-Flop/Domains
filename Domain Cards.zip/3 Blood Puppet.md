---
Color: "#6c1713"
Domain: Blood
Level: "3"
tags:
  - level3
---

##### -- Blood Puppet
Level: 3
Domain: Blood
Type: Spell
Recall Cost: 2
Make a Spellcast Roll against a creature (living or dead) within Far range. On a success, spend a Hope to control the target by causing them to move, attack, or both. If you do both, you choose the order. If you cause the creature to move, they move to a location you choose that’s within Close range of them. If you cause the creature to attack, make a Spellcast Roll against a target within Melee range of them. On a success, deal d10 physical damage using your Proficiency.