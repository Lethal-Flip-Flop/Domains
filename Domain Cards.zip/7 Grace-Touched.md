---
Color: "#b03a7c"
Domain: Grace
Level: "7"
tags:
  - level7
---

##### -- Grace-Touched
Level: 7
Domain: Grace
Type: Ability
Recall Cost: 2
When 4 or more of the domain cards in your loadout are from the Grace domain, gain the following benefits:

- You can mark an Armor Slot instead of marking a Stress.
- When you would force a target to mark a number of Hit Points, you can choose instead to force them to mark that number of Stress.