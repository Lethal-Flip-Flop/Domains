---
Color: "#434445"
Domain: Midnight
Level: "8"
tags:
  - level8
---

##### -- Spellcharge
Level: 8
Domain: Midnight
Type: Spell
Recall Cost: 1
When you take magic damage, place tokens equal to the number of Hit Points you marked on this card. You can store a number of tokens equal to your Spellcast trait.

When you make a successful attack against a target, you can spend any number of tokens to add a d 6 for each token spent to your damage roll.