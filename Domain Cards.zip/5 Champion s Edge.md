---
Color: "#9f3630"
Domain: Blade
Level: "5"
tags:
  - level5
---

##### -- Champion’s Edge
Level: 5
Domain: Blade
Type: Ability
Recall Cost: 1
When you critically succeed on an attack, you can spend up to 3 Hope and choose one of the following options for each Hope spent:

You clear a Hit Point.
You clear an Armor Slot.
The target must mark an additional Hit Point.
You can’t choose the same option more than once.