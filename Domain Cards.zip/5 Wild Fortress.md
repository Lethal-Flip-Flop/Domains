---
Color: "#197d4a"
Domain: Sage
Level: "5"
tags:
  - level5
---

##### -- Wild Fortress
Level: 5
Domain: Sage
Type: Spell
Recall Cost: 1
Make a Spellcast Roll (13). On a success, spend 2 Hope to grow a natural barricade in the shape of a dome that you and one ally can take cover within. While inside the dome, a creature can’t be targeted by attacks and can’t make attacks. Attacks made against the dome automatically succeed. The dome has a Major damage threshold of 15 and a Severe damage threshold of 30, and lasts until it marks 3 Hit Points. Place tokens on this card to represent marking Hit Points.