---
Color: "#b03a7c"
Domain: Grace
Level: "8"
tags:
  - level8
---

##### -- Mass Enrapture
Level: 8
Domain: Grace
Type: Spell
Recall Cost: 3
Make a Spellcast Roll against all targets within Far range. Targets you succeed against become temporarily Enraptured. While Enraptured, a target’s attention is fixed on you, narrowing their field of view and drowning out any sound but your voice. Mark a Stress to force all Enraptured targets to mark a Stress, ending this spell.