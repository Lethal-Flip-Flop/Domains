---
Color: "#3a3174"
Domain: Dread
Level: "10"
tags:
  - level10
---

##### -- Invoke Torment
Level: 10
Domain: Dread
Type: Spell
Recall Cost: 2
Targets with all of their Stress marked take double damage from your attacks.

Additionally, when you defeat a creature with all of its Stress marked, you clear a Stress.