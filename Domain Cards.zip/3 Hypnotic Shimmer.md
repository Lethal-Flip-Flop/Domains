---
Color: "#b03a7c"
Domain: Grace
Level: "3"
tags:
  - level3
---

##### -- Hypnotic Shimmer
Level: 3
Domain: Grace
Type: Spell
Recall Cost: 1
Make a Spellcast Roll against all adversaries in front of you within Close range. Once per rest on a success, create an illusion of flashing colors and lights that temporarily Stuns targets you succeed against and forces them to mark a Stress. While Stunned, they can’t use reactions and can’t take any other actions until they clear this condition.