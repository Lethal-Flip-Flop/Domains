---
Color: "#895b95"
Domain: Arcana
Level: "10"
tags:
  - level10
---

##### -- Adjust Reality
Level: 10
Domain: Arcana
Type: Spell
Recall Cost: 1
After you or a willing ally make any roll, you can spend 5 Hope to change the numerical result of that roll to a result of your choice instead. The result must be plausible within the range of the dice.