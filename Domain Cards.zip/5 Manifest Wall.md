---
Color: "#385e8e"
Domain: Codex
Level: "5"
tags:
  - level5
---

##### -- Manifest Wall
Level: 5
Domain: Codex
Type: Grimoire
Recall Cost: 2
Make a Spellcast Roll (15). Once per rest on a success, spend a Hope to create a temporary magical wall between two points within Far range. It can be up to 50 feet high and form at any angle. Creatures or objects in its path are shunted to a side of your choice. The wall stays up until your next rest or you cast Manifest Wall again.