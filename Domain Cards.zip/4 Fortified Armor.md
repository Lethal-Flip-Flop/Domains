---
Color: "#9f3630"
Domain: Blade
Level: "4"
tags:
  - level4
---

##### -- Fortified Armor
Level: 4
Domain: Blade
Type: Ability
Recall Cost: -
While you are wearing armor, gain a +2 bonus to your damage thresholds.