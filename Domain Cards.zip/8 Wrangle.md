---
Color: "#999b9c"
Domain: Bone
Level: "8"
tags:
  - level8
---

##### -- Wrangle
Level: 8
Domain: Bone
Type: Ability
Recall Cost: 1
Make an Agility Roll against all targets within Close range. Spend a Hope to move targets you succeed against, and any willing allies within Close range, to another point within Close range.