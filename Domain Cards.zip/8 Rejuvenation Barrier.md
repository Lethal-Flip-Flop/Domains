---
Color: "#197d4a"
Domain: Sage
Level: "8"
tags:
  - level8
---

##### -- Rejuvenation Barrier
Level: 8
Domain: Sage
Type: Spell
Recall Cost: 1
Make a Spellcast Roll (15). Once per rest on a success, create a temporary barrier of protective energy around you at Very Close range. You and all allies within the barrier when this spell is cast clear 1 d 4 Hit Points. While the barrier is up, you and all allies within have resistance to physical damage from outside the barrier.

When you move, the barrier follows you.