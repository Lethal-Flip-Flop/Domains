---
Color: "#895b95"
Domain: Arcana
Level: "5"
tags:
  - level5
---

##### -- Premonition
Level: 5
Domain: Arcana
Type: Spell
Recall Cost: 2
You can channel arcane energy to have visions of the future. Once per long rest, immediately after the GM conveys the consequences of a roll you made, you can rescind the move and consequences like they never happened and make another move instead.