---
Color: "#197d4a"
Domain: Sage
Level: "1"
tags:
  - Level1
---

##### -- Vicious Entangle
Level: 1 
Domain: Sage
Type: Spell
Recall Cost: 1
Make a Spellcast Roll against a target within Far range. On a success, roots and vines reach out from the ground, dealing 1 d 8+1 physical damage and temporarily Restraining the target.

Additionally on a success, you can spend a Hope to temporarily Restrain another adversary within Very Close range of your target.