---
Color: "#dabb2e"
Domain: Splendor
Level: "1"
tags:
  - Level1
---

##### -- Bolt Beacon
Level: 1 
Domain: Splendor
Type: Spell
Recall Cost: 1
Make a Spellcast Roll against a target within Far range. On a success, spend a Hope to send a bolt of shimmering light toward them, dealing d8+2 magic damage using your Proficiency. The target becomes temporarily Vulnerable and glows brightly until this condition is cleared.
