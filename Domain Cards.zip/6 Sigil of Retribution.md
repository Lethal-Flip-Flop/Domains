---
Color: "#385e8e"
Domain: Codex
Level: "6"
tags:
  - level6
---

##### -- Sigil of Retribution
Level: 6
Domain: Codex
Type: Spell
Recall Cost: 2
Mark an adversary within Close range with a sigil of retribution. The GM gains a Fear. When the marked adversary deals damage to you or your allies, place a d8 on this card. You can hold a number of d8s equal to your level. When you successfully attack the marked adversary, roll the dice on this card and add the total to your damage roll, then clear the dice. This effect ends when the marked adversary is defeated or you cast Sigil of Retribution again.