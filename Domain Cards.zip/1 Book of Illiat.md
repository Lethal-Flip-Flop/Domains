---
Color: "#385e8e"
Domain: Codex
Level: "1"
tags:
  - Level1
---

##### -- Book of Illiat
Level: 1 
Domain: Codex
Type: Grimoire
Recall Cost: 2
Slumber: Make a Spellcast Roll against a target within Very Close range. On a success, they’re Asleep until they take damage or the GM spends a Fear on their turn to clear this condition.

Arcane Barrage: Once per rest, spend any number of Hope and shoot magical projectiles that strike a target of your choice within Close range. Roll a number of d 6 s equal to the Hope spent and deal that much magic damage to the target.

Telepathy: Spend a Hope to open a line of mental communication with one target you can see. This connection lasts until your next rest or you cast Telepathy again.
