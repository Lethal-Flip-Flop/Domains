---
Color: "#197d4a"
Domain: Sage
Level: "6"
tags:
  - level6
---

##### -- Conjured Steeds
Level: 6
Domain: Sage
Type: Spell
Recall Cost: -
Spend any number of Hope to conjure that many magical steeds (such as horses, camels, or elephants) that you and your allies can ride until your next long rest or the steeds take any damage. The steeds double your land speed while traveling and, when in danger, allow you to move within Far range without having to roll. Creatures riding a steed gain a −2 penalty to attack rolls and a +2 bonus to damage rolls.