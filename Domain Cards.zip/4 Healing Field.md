---
Color: "#197d4a"
Domain: Sage
Level: "4"
tags:
  - level4
---

##### -- Healing Field
Level: 4
Domain: Sage
Type: Spell
Recall Cost: 2
Once per long rest, you can conjure a field of healing plants around you. Everywhere within Close range of you bursts to life with vibrant nature, allowing you and all allies in the area to clear a Hit Point.

Spend 2 Hope to allow you and all allies to clear 2 Hit Points instead.