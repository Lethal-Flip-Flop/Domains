---
Color: "#3a3174"
Domain: Dread
Level: "2"
tags:
  - level2
---

##### -- Hideous Retribution
Level: 2
Domain: Dread
Type: Spell
Recall Cost: 2
When an ally within Close range takes damage from a target you can see, you can make a Spellcast Reaction Roll against the target. On a success, mark a Stress to deal them d6 magic damage using your Proficiency.