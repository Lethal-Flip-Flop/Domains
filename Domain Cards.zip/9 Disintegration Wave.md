---
Color: "#385e8e"
Domain: Codex
Level: "9"
tags:
  - level9
---

##### -- Disintegration Wave
Level: 9
Domain: Codex
Type: Spell
Recall Cost: 4
Make a Spellcast Roll (18). Once per long rest on a success, the GM tells you which adversaries within Far range have a Difficulty of 18 or lower. Mark a Stress for each one you wish to hit with this spell. They are killed and can’t come back to life by any means.