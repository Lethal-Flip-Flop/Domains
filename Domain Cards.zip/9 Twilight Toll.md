---
Color: "#434445"
Domain: Midnight
Level: "9"
tags:
  - level9
---

##### -- Twilight Toll
Level: 9
Domain: Midnight
Type: Ability
Recall Cost: 1
Choose a target within Far range. When you succeed on an action roll against them that doesn’t result in making a damage roll, place a token on this card. When you deal damage to this target, spend any number of tokens to add a d 12 for each token spent to your damage roll. You can only hold Twilight Toll on one creature at a time.

When you choose a new target or take a rest, clear all unspent tokens.