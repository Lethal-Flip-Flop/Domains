---
Color: "#b03a7c"
Domain: Grace
Level: "6"
tags:
  - level6
---

##### -- Never Upstaged
Level: 6
Domain: Grace
Type: Ability
Recall Cost: 2
When you mark 1 or more Hit Points from an attack, you can mark a Stress to place a number of tokens equal to the number of Hit Points you marked on this card. On your next successful attack, gain a +5 bonus to your damage roll for each token on this card, then clear all tokens.