---
Color: "#6c1713"
Domain: Blood
Level: "7"
tags:
  - level7
---

##### -- Vampiric Strike
Level: 7
Domain: Blood
Type: Spell
Recall Cost: 2
When you make a successful attack roll against an adversary and cause them to mark 2 or more Hit Points, you can spend a Hope to clear a Hit Point or Stress.