---
Color: "#9f3630"
Domain: Blade
Level: "6"
tags:
  - level6
---

##### -- Rage Up
Level: 6
Domain: Blade
Type: Ability
Recall Cost: 1
Before you make an attack, you can mark a Stress to gain a bonus to your damage roll equal to twice your Strength.

You can Rage Up twice per attack.