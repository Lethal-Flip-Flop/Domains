---
Color: "#cd762a"
Domain: Valor
Level: "9"
tags:
  - level9
---

##### -- Hold the Line
Level: 9
Domain: Valor
Type: Ability
Recall Cost: 1
Describe the defensive stance you take and spend a Hope. If an adversary moves within Very Close range, they’re pulled into Melee range and Restrained.

This condition lasts until you move or fail a roll with Fear, or the GM spends 2 Fear on their turn to clear it.