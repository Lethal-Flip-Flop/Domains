---
Color: "#999b9c"
Domain: Bone
Level: "10"
tags:
  - level10
---

##### -- Swift Step
Level: 10
Domain: Bone
Type: Ability
Recall Cost: 2
When an attack made against you fails, clear a Stress. If you can’t clear a Stress, gain a Hope.