---
Color: "#6c1713"
Domain: Blood
Level: "4"
tags:
  - level4
---

##### -- Weave the Flesh
Level: 4
Domain: Blood
Type: Spell
Recall Cost: 1
Once per rest, mark a Hit Point to allow each ally within Close range to clear a Hit Point or a Stress. You can mark a Stress to allow those allies to clear one of each.