---
Color: "#999b9c"
Domain: Bone
Level: "6"
---
#level6
##### -- Rapid Riposte
Level: 6
Domain: Bone
Type: Ability
Recall Cost: -
When an attack made against you from within Melee range fails, you can mark a Stress and seize the opportunity to deal the weapon damage of one of your active weapons to the attacker.