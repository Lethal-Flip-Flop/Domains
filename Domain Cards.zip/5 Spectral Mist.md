---
Color: "#3a3174"
Domain: Dread
Level: "5"
tags:
  - level5
---

##### -- Spectral Mist
Level: 5
Domain: Dread
Type: Spell
Recall Cost: -
Mark a Stress to summon an eerie mist that turns you and any targets within Close range momentarily incorporeal. While a creature is incorporeal, they can move through solid objects and are immune to physical damage. A creature becomes corporeal again after they pass through a solid object or make an action roll. Otherwise, this effect drops at the end of the scene.