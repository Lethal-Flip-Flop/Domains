---
Color: "#197d4a"
Domain: Sage
Level: "10"
tags:
  - level10
---

##### -- Tempest
Level: 10
Domain: Sage
Type: Spell
Recall Cost: 2
Choose one of the following tempests and make a Spellcast Roll against all targets within Far range. Targets you succeed against experience its effects until the GM spends a Fear on their turn to end this spell.

- Blizzard: Deal 2 d 20+8 magic damage and targets are temporarily Vulnerable.
- Hurricane: Deal 3 d 10+10 magic damage and choose a direction the wind is blowing. Targets can’t move against the wind.
- Sandstorm: Deal 5 d 6+9 magic damage. Attacks made from beyond Melee range have disadvantage.