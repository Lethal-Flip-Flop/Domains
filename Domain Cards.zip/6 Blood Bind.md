---
Color: "#6c1713"
Domain: Blood
Level: "6"
tags:
  - level6
---

##### -- Blood Bind
Level: 6
Domain: Blood
Type: Spell
Recall Cost: 2
Make a Spellcast Roll against a target within Far range. On a success, mark a Stress as you slow the target’s vitality. The target is temporarily Restrained and temporarily Vulnerable. Each time the target is spotlighted while either of these conditions persists on them, the target takes d10 magic damage using your Proficiency. The spell ends early on the target if you use it again.