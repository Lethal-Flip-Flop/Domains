---
Color: "#999b9c"
Domain: Bone
Level: "3"
tags:
  - level3
---

##### -- Tactician
Level: 3
Domain: Bone
Type: Ability
Recall Cost: 1
When you Help an Ally, they can spend a Hope to add one of your Experiences to their roll alongside your advantage die.

When making a Tag Team Roll, you can roll a d 20 as your Hope Die.