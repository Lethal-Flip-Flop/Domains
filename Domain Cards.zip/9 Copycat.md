---
Color: "#b03a7c"
Domain: Grace
Level: "9"
tags:
  - level9
---

##### -- Copycat
Level: 9
Domain: Grace
Type: Spell
Recall Cost: 3
Once per long rest, this card can mimic the features of another domain card of level 8 or lower in another player’s loadout. Spend Hope equal to half the card’s level to gain access to the feature. It lasts until your next rest or they place the card in their vault.