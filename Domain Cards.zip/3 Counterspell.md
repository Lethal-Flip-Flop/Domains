---
Color: "#895b95"
Domain: Arcana
Level: "3"
tags:
  - level3
---

##### -- Counterspell
Level: 3
Domain: Arcana
Type: Spell
Recall Cost: 2 
You can interrupt a magical effect taking place by making a reaction roll using your Spellcast trait. On a success, the effect stops and any consequences are avoided, and this card is placed in your vault.