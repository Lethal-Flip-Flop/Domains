---
Color: "#b03a7c"
Domain: Grace
Level: "10"
tags:
  - level10
---

##### -- Encore
Level: 10
Domain: Grace
Type: Spell
Recall Cost: 1
When an ally within Close range deals damage to an adversary, you can make a Spellcast Roll against that same target. On a success, you deal the same damage to the target that your ally dealt. If your Spellcast Roll succeeds with Fear, place this card in your vault.