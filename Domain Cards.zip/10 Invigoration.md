---
Color: "#dabb2e"
Domain: Splendor
Level: "10"
tags:
  - level10
---

##### -- Invigoration
Level: 10
Domain: Splendor
Type: Spell
Recall Cost: 3
When you or an ally within Close range has used a feature that has an exhaustion limit (such as once per rest or once per session), you can spend any number of Hope and roll that many d6s. If any roll a 6, the feature can be used again.