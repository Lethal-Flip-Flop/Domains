---
Color: "#9f3630"
Domain: Blade
Level: "7"
tags:
  - level7
---

##### -- Glancing Blow
Level: 7
Domain: Blade
Type: Ability
Recall Cost: 1
When you fail an attack, you can mark a Stress to deal weapon damage using half your Proficiency.