---
Color: "#999b9c"
Domain: Bone
Level: "6"
---
#level6
##### -- Recovery
Level: 6
Domain: Bone
Type: Ability
Recall Cost: 1
During a short rest, you can choose a long rest downtime move instead. You can spend a Hope to let an ally do the same.