---
Color: "#3a3174"
Domain: Dread
Level: "3"
tags:
  - level3
---

##### -- Terrify
Level: 3
Domain: Dread
Type: Spell
Recall Cost: 1
Make a Spellcast Roll against a target within Far range. On a success, the target marks 1d4 Stress and you can choose to make the target run one range away from you (Close to Far, Far to Very Far, etc). On a success with Fear, the target becomes temporarily Vulnerable.