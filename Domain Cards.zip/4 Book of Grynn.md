---
Color: "#385e8e"
Domain: Codex
Level: "4"
tags:
  - level4
---

##### -- Book of Grynn
Level: 4
Domain: Codex
Type: Grimoire
Recall Cost: 2
Arcane Deflection: Once per long rest, spend a Hope to negate the damage of an attack targeting you or an ally within Very Close range.

Time Lock: Target an object within Far range. That object stops in time and space exactly where it is until your next rest. If a creature tries to move it, make a Spellcast Roll against them to maintain this spell.

Wall of Flame: Make a Spellcast Roll (15). On a success, create a temporary wall of magical flame between two points within Far range. All creatures in its path must choose a side to be on, and anything that subsequently passes through the wall takes 4 d 10+3 magic damage.