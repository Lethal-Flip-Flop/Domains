---
Color: "#3a3174"
Domain: Dread
Level: "6"
tags:
  - level6
---

##### -- Darkfire
Level: 6
Domain: Dread
Type: Spell
Recall Cost: 2
Make a Spellcast Roll against all adversaries within Close range. You can spend a Hope for any you succeed against, and they must make a Reaction Roll (14) . On a failure, they take d8+6 magic damage using your Proficiency as they are engulfed in dark fire. On a success, they take half damage.