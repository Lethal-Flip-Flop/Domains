---
Color: "#3a3174"
Domain: Dread
Level: "1"
tags:
  - Level1
---

##### -- Voice of Dread
Level: 1 
Domain: Dread
Type: Spell
Recall Cost: -
You can magically speak directly into the ears of a creature you can see. To torment them with your words, make a Spellcast Roll against them. On a success, they must mark a Stress and become temporarily Vulnerable.