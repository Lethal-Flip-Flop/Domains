---
Color: "#999b9c"
Domain: Bone
Level: "1"
tags:
  - Level1
---

##### -- Deft Maneuvers
Level: 1 
Domain: Bone
Type: Ability
Recall Cost: -
Once per rest, mark a Stress to sprint anywhere within Far range without making an Agility Roll to get there.

If you end this movement within Melee range of an adversary and immediately make an attack against them, gain a +1 bonus to the attack roll.
