---
Color: "#6c1713"
Domain: Blood
Level: "1"
tags:
  - Level1
---

##### -- Power Through Pain
Level: 1 
Domain: Blood
Type: Ability
Recall Cost: 1
If you have at least one Hit Point marked, you gain a bonus to your damage rolls. The bonus equals twice your number of marked Hit Points.