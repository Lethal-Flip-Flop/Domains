---
Color: "#434445"
Domain: Midnight
Level: "1"
tags:
  - Level1
---

##### -- Pick and Pull
Level: 1 
Domain: Midnight
Type: Ability
Recall Cost: -
You have advantage on action rolls to pick nonmagical locks, disarm nonmagical traps, or steal items from a target (either through stealth or by force).