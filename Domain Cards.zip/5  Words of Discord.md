---
Color: "#b03a7c"
Domain: Grace
Level: "5"
tags:
  - level5
---

##### -- Words of Discord
Level: 5
Domain: Grace
Type: Spell
Recall Cost: 1
Whisper words of discord to an adversary within Melee range and make a Spellcast Roll (13). On a success, the target must mark a Stress and make an attack against another adversary instead of against you or your allies.

Once this attack is over, the target realizes what happened. The next time you cast Words of Discord on them, gain a −5 penalty to the Spellcast Roll.