---
Color: "#6c1713"
Domain: Blood
Level: "9"
tags:
  - level9
---

##### -- Bloodbath
Level: 9
Domain: Blood
Type: Spell
Recall Cost: 2
Once per rest, spend a Hope to unleash waves of blood around yourself. Make a single Spellcast Roll against each adversary within Close range. On a success, a target marks a Hit Point and a Stress. On a failure, a target marks a Stress.

Each ally within Close range marks a Stress but clears a Hit Point.