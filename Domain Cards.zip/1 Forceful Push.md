---
Color: "#cd762a"
Domain: Valor
Level: "1"
tags:
  - Level1
---

##### -- Forceful Push
Level: 1 
Domain: Valor
Type: Ability
Recall Cost: -
Make an attack with your primary weapon against a target within Melee range. On a success, you deal damage and knock them back to Close range. On a success with Hope, add a d 6 to your damage roll.

Additionally, you can spend a Hope to make them temporarily Vulnerable.