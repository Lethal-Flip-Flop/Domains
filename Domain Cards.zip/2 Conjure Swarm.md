---
Color: "#197d4a"
Domain: Sage
Level: "2"
tags:
  - level2
---

##### -- Conjure Swarm
Level: 2
Domain: Sage
Type: Spell
Recall Cost: 1
Tekaira Armored Beetles: Mark a Stress to conjure armored beetles that encircle you. When you next take damage, reduce the severity by one threshold. You can spend a Hope to keep the beetles conjured after taking damage.

Fire Flies: Make a Spellcast Roll against all adversaries within Close range. Spend a Hope to deal 2 d 8+3 magic damage to targets you succeeded against.