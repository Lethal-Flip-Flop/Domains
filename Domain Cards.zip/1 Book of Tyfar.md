---
Color: "#385e8e"
Domain: Codex
Level: "1"
tags:
  - Level1
---

##### -- Book of Tyfar
Level: 1 
Domain: Codex
Type: Grimoire
Recall Cost: 2
Wild Flame: Make a Spellcast Roll against up to three adversaries within Melee range. Targets you succeed against take 2 d 6 magic damage and must mark a Stress as flames erupt from your hand.

Magic Hand: You conjure a magical hand with the same size and strength as your own within Far range.

Mysterious Mist: Make a Spellcast Roll (13) to cast a temporary thick fog that gathers in a stationary area within Very Close range. The fog heavily obscures this area and everything in it.


