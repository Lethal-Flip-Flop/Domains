---
Color: "#dabb2e"
Domain: Splendor
Level: "5"
tags:
  - level5
---

##### -- Shape Material
Level: 5
Domain: Splendor
Type: Spell
Recall Cost: 1
Spend a Hope to shape a section of natural material you’re touching (such as stone, ice, or wood) to suit your purpose. The area of the material can be no larger than you. For example, you can form a rudimentary tool or create a door.

You can only affect the material within Close range of where you’re touching it.