---
Color: "#999b9c"
Domain: Bone
Level: "4"
tags:
  - level4
---

##### -- Boost
Level: 4
Domain: Bone
Type: Ability
Recall Cost: 1
Mark a Stress to boost off a willing ally within Close range, fling yourself into the air, and perform an aerial attack against a target within Far range. You have advantage on the attack, add a d10 to the damage roll, and end your move within Melee range of the target.