---
Color: "#197d4a"
Domain: Sage
Level: "9"
tags:
  - level9
---

##### -- Plant Dominion
Level: 9
Domain: Sage
Type: Spell
Recall Cost: 1
Make a Spellcast Roll (18). Once per long rest on a success, you reshape the natural world, changing the surrounding plant life anywhere within Far range of you. For example, you can grow trees instantly, clear a path through dense vines, or create a wall of roots.