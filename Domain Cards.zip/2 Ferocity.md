---
Color: "#999b9c"
Domain: Bone
Level: "2"
tags:
  - level2
---

##### -- Ferocity
Level: 2
Domain: Bone
Type: Ability
Recall Cost: 2
When you cause an adversary to mark 1 or more Hit Points, you can spend 2 Hope to increase your Evasion by the number of Hit Points they marked. This bonus lasts until after the next attack made against you.