---
Color: "#895b95"
Domain: Arcana
Level: "1"
tags:
  - Level1
---

##### -- Unleash Chaos
Level: 1 
Domain: Arcana
Type: Spell
Recall Cost: 1
At the beginning of a session, place a number of tokens equal to your Spellcast trait on this card.

Make a Spellcast Roll against a target within Far range and spend any number of tokens to channel raw energy from within yourself to unleash against them. On a success, roll a number of d 10 s equal to the tokens you spent and deal that much magic damage to the target. Mark a Stress to replenish this card with tokens (up to your Spellcast trait).

At the end of each session, clear all unspent tokens.