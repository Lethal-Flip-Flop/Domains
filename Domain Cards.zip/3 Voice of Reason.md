---
Color: "#dabb2e"
Domain: Splendor
Level: "3"
tags:
  - level3
---

##### -- Voice of Reason
Level: 3
Domain: Splendor
Type: Ability
Recall Cost: 1
You speak with an unmatched power and authority. You have advantage on action rolls to de-escalate violent situations or convince someone to follow your lead.

Additionally, you’re emboldened in moments of duress. When all of your Stress slots are marked, you gain a +1 bonus to your Proficiency for damage rolls.