---
Color: "#6c1713"
Domain: Blood
Level: "3"
tags:
  - level3
---

##### -- Burning Blood
Level: 3
Domain: Blood
Type: Spell
Recall Cost: 2
Make a Spellcast Roll (12). On a success, mark a Hit Point as you conjure a bead of blood, which you lob at a point within Far range. A wave of heat fills the area within Very Close range of that point, igniting the internal vitals of those caught within. Each target within the area marks 1 Hit Point. On a success with Hope, each target within the area instead marks 2 Hit Points.