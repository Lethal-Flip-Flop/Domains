---
Color: "#999b9c"
Domain: Bone
Level: "4"
tags:
  - level4
---

##### -- Redirect
Level: 4
Domain: Bone
Type: Ability
Recall Cost: 1
When an attack made against you from beyond Melee range fails, roll a number of d6s equal to your Proficiency. If any roll a 6, you can mark a Stress to redirect the attack to damage an adversary within Very Close range instead.