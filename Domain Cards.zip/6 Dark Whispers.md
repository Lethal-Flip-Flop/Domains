---
Color: "#434445"
Domain: Midnight
Level: "6"
tags:
  - level6
---

##### -- Dark Whispers
Level: 6
Domain: Midnight
Type: Spell
Recall Cost: -
You can speak into the mind of any person with whom you’ve made physical contact. Once you’ve opened a channel with them, they can speak back into your mind. Additionally, you can mark a Stress to make a Spellcast Roll against them. On a success, you can ask the GM one of the following questions and receive an answer:

- Where are they?
- What are they doing?
- What are they afraid of?
- What do they cherish most in the world?