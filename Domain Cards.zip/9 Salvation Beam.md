---
Color: "#dabb2e"
Domain: Splendor
Level: "9"
tags:
  - level9
---

##### -- Salvation Beam
Level: 9
Domain: Splendor
Type: Spell
Recall Cost: 2
Make a Spellcast Roll (16). On a success, mark any number of Stress to target a line of allies within Far range. You can clear Hit Points on the targets equal to the number of Stress marked, divided among them however you’d like.