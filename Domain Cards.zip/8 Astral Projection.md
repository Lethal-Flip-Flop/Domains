---
Color: "#b03a7c"
Domain: Grace
Level: "8"
tags:
  - level8
---

##### -- Astral Projection
Level: 8
Domain: Grace
Type: Spell
Recall Cost: 0
Once per long rest, mark a Stress to create a projected copy of yourself that can appear anywhere you’ve been before.

You can see and hear through the projection as though it were you and affect the world as though you were there. A creature investigating the projection can tell it’s of magical origin. This effect lasts until your next rest or your projection takes any damage.