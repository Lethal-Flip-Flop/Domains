---
Color: "#3a3174"
Domain: Dread
Level: "6"
tags:
  - level6
---

##### -- Jump Scare
Level: 6
Domain: Dread
Type: Spell
Recall Cost: -
When you deal magic damage to a target, you can mark a Stress to immediately teleport into Melee range of them. When you do, they become Vulnerable until they mark one or more Hit Points.