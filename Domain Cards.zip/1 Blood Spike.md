---
Color: "#6c1713"
Domain: Blood
Level: "1"
tags:
  - Level1
---

##### -- Blood Spike
Level: 1 
Domain: Blood
Type: Spell
Recall Cost: 1
Make a Spellcast Roll against a target within Far range. On a success, mark a Stress to deal d10 magic damage to the target using your Proficiency. On a success with Hope, the target also marks a Stress. On a roll with Fear, mark a Stress.

