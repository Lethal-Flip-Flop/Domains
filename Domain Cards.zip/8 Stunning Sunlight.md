---
Color: "#dabb2e"
Domain: Splendor
Level: "8"
tags:
  - level8
---

##### -- Stunning Sunlight
Level: 8
Domain: Splendor
Type: Spell
Recall Cost: 2
Make a Spellcast Roll to unleash powerful rays of burning sunlight against all adversaries in front of you within Far range. On a success, spend any number of Hope and force that many targets you succeeded against to make a Reaction Roll (14).

Targets who succeed take 3 d 20+3 magic damage. Targets who fail take 4 d 20+5 magic damage and are temporarily Stunned. While Stunned, they can’t use reactions and can’t take any other actions until they clear this condition.