---
Color: "#6c1713"
Domain: Blood
Level: "1"
tags:
  - Level1
---

##### -- Lifeblood Talisman
Level: 1 
Domain: Blood
Type: Spell
Recall Cost: -
Mark a Hit Point to conjure a talisman infused with your life essence. The talisman appears in your hand, and whoever carries the talisman gains its benefit: Whenever the talisman’s bearer marks 2 or more Hit Points, they can spend a Hope to reduce the number of Hit Points marked by 1. The talisman disappears if you have no Hit Points marked or you use this spell again.