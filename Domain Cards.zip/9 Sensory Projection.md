---
Color: "#895b95"
Domain: Arcana
Level: "9"
tags:
  - level9
---

##### -- Sensory Projection
Level: 9
Domain: Arcana
Type: Spell
Recall Cost: 0
Once per rest, make a Spellcast Roll (15). On a success, drop into a vision that lets you clearly see and hear any place you have been before as though you are standing there in this moment. You can move freely in this vision and are not constrained by the physics or impediments of a physical body. This spell cannot be detected by mundane or magical means. You drop out of this vision upon taking damage or casting another spell.