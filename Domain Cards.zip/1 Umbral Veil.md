---
Color: "#3a3174"
Domain: Dread
Level: "1"
tags:
  - Level1
---

##### -- Umbral Veil
Level: 1 
Domain: Dread
Type: Spell
Recall Cost: 1
Once per rest, when you roll with Fear, you can spend any number of Hope to place an equal number of tokens on this card, encasing yourself in a shadowy energy. After an attack roll is made against you, you can spend any number of tokens to give the attack roll a -1 penalty per token. On your next rest, remove all tokens from this card.