---
Color: "#dabb2e"
Domain: Splendor
Level: "1"
tags:
  - Level1
---

##### -- Mending Touch
Level: 1 
Domain: Splendor
Type: Spell
Recall Cost: 1
You lay your hands upon a creature and channel healing magic to close their wounds. When you can take a few minutes to focus on the target you’re helping, you can spend 2 Hope to clear a Hit Point or a Stress on them.

Once per long rest, when you spend this healing time learning something new about them or revealing something about yourself, you can clear 2 Hit Points or 2 Stress on them instead.