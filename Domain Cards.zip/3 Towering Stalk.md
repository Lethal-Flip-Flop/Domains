---
Color: "#197d4a"
Domain: Sage
Level: "3"
tags:
  - level3
---

##### -- Towering Stalk
Level: 3
Domain: Sage
Type: Spell
Recall Cost: 1
Once per rest, you can conjure a thick, twisting stalk within Close range that can be easily climbed. Its height can grow up to Far range.

Mark a Stress to use this spell as an attack. Make a Spellcast Roll against an adversary or group of adversaries within Close range. The erupting stalk lifts targets you succeed against into the air and drops them, dealing d 8 physical damage using your Proficiency.
