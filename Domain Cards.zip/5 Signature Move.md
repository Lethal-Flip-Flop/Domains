---
Color: "#999b9c"
Domain: Bone
Level: "5"
tags:
  - level5
---

##### -- Signature Move
Level: 5
Domain: Bone
Type: Ability
Recall Cost: 1
Name and describe your signature combat move. Once per rest, when you perform this signature move as part of an action you’re taking, you can roll a d 20 as your Hope Die. On a success, clear a Stress.