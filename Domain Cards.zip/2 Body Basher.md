---
Color: "#cd762a"
Domain: Valor
Level: "2"
tags:
  - level2
---

##### -- Body Basher
Level: 2
Domain: Valor
Type: Ability
Recall Cost: 1
You use the full force of your body in a fight. On a successful attack using a weapon with a Melee range, gain a bonus to your damage roll equal to your Strength.