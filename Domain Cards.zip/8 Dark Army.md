---
Color: "#3a3174"
Domain: Dread
Level: "8"
tags:
  - level8
---

##### -- Dark Army
Level: 8
Domain: Dread
Type: Spell
Recall Cost: 2
Make a Spellcast Roll (14) . Once per long rest, on a success you can summon a group of fiends that surround and move with you. Place 8 tokens on this card. When you deal damage to a target within Very Close range, you can spend a token to increase it by +1 d 8. Additionally, when you take damage, you can spend a token to reduce it by 1 d 8. Each time you spend a token, a fiend acts on your behalf, then disappears.

Remove all tokens from this card on your next rest.