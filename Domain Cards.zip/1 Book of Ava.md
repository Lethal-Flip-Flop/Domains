---
Color: "#385e8e"
Domain: Codex
Level: "1"
tags:
  - Level1
---

##### -- Book of Ava
Level: 1 
Domain: Codex
Type: Grimoire
Recall Cost: 2
Power Push: Make a Spellcast Roll against a target within Melee range. On a success, they’re knocked back to Far range and take d 10+2 magic damage using your Proficiency.

Tava’s Armor: Spend a Hope to give a target you can touch a +1 bonus to their Armor Score until their next rest or you cast Tava’s Armor again.

Ice Spike: Make a Spellcast Roll (12) to summon a large ice spike within Far range. If you use it as a weapon, make the Spellcast Roll against the target’s Difficulty instead. On a success, deal d 6 physical damage using your Proficiency.

