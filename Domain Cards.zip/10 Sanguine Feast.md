---
Color: "#6c1713"
Domain: Blood
Level: "10"
tags:
  - level10
---

##### -- Sanguine Feast
Level: 10
Domain: Blood
Type: Spell
Recall Cost: 2
Make a Spellcast Roll against an adversary within Close range. On a success, spend 2 Hope to mark 1–3 Hit Points, and the target marks twice the number of the Hit Points you marked. If this causes the target to mark their last Hit Point, you can clear the Hit Points you marked to cast this spell.